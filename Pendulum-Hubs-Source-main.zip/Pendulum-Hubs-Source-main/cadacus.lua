warn("<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>")	

			warn(">Caducus the Fallen God<")
	
warn("Script created by SezHu for public use in Void's Script Builder.")

warn("<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>")


--[[

		>D͕̪͇̪̻̼͙o̶̱̣͙̱̦̚ ͔͈̱̲̆̄ͫ̾n̺͉̻͍̻̂ͦ̓̈ͤ́ơ̮̤̙̯ͤ͐ͬ̏ͥt̞̹̜͇̏ͩ̕ ̙̰̠͕ͤw̘ͨ̑̓̍͋ͩ͌o̡̞̦̜̟̻̐ͨͦ͐ͨ͊͗r̬͊̔̓͑͆̚r̳̬ͤ̓͌̿̅y͜ ̗̭͇͈̖̠̔̌c̨̊̑̔h̳̪͈̟͇̺̱i̻̳̥̭͚̘ͪ͂̄̊̄͒ͨl̝̗̙̀d̜̍ͧ̐̓̒̆͐ͅ,̸͓̠ͨ̍̌ͩ̾ͭ ̷̝͔̺̯̖̰̓͌ͫ͆͋ͩͅt̶̬͍̲̮̹̙͐̃ͭͨ̑hͯ̓̍ḙ̪͍̖͉̾ͨ ̯͙̓ͯ̍̔͡p̟̩ả͏͍̜͖̦̩̣i͏̳̘̝̞ͅṅ̼̯̆̾̉͆̏ͫ ̦͕͊͌̏̀̾̏̀̚w͙̗̝̼̖ͧͪͤ̓̄͐ͅiͧ̎̍͛͡l̡̦̖̦̖̃ͫ͌l̫̪͔̫̮͚͋̚ ̮̣̣͉͉̝̀ͅb̸ͩ́͑͋͗͋̽ë̼̺̱̦͚͕́̈́̈ͨ͞ ̯̦̫̿̓͞o̖̺̟̮͛̋̓͐ͫv̍͊͆ͨ̽e̢͔̱̝ͪ̍ͥͭ͆ͯ̅ͅṛ͔͉̥̬͙̆̌ ̘̖͉̰ͧͦ̈͢s̫̹̯̪͆̓̾͘o̧͙͙̖̗̮͍̹̓ͦ͛͒̔o̪̫͋͌̂̏̄ñ̰̫͎̦̆̓͒̓<


		>Y̹̟̼̞̦ͥ̏̓o̗̳̗̭ͨ̆͊̊͌̉ͅͅu̪͒̇͛̚ͅr̟̲͙̹̽̓ ͂͢s̢̞̮̞ͥ̊ͦͯ͋̏t͚͚̺̭̥͓̗ͪ̿ͦ͐r͕͎̰̟̝̦͚ͫͩ̀u͛ͤ͌g͇̼̘̗ͣ̎͂̔̿͋g̙̜͇̼̝͔̋l͗̍̿̇ͧͯ͏̗̞̟̜e͏ ̺̤͍͈ͨ̈́͢i̜̤̤͖͓͕͐͂ͨ̊s̹͚͈̮̦ͬͥ̄̾̆ͧ̚ ̙͚̓̾n͎͓̟̞̺̥̾ͦ̐̂ͧo̾͆͠t̗͙̰̟̫ͦ ̷̰̜͇̣̼̗̐̎̂̚ì̗̼͖̬͎̪̭ͮͩ̓ṋ̝ͣ ͔v̢̮̘̟̾ͨa̵̬̙̻ͤͨ͂͌ͬͅi̱̘͓ͩ͛̇̓ͯ͜n͋̌͛̈́.̰͙ͫ<


		>We̛͎͍̥͚͔ͥ̃͂ ̮̥͔̝̟̅̅͌ͭ̃ͯͨ͠s̩͕͕̿̐͒ͦ̐ͪh͓̖̓ͣ̉͒ͬ̋̚a̱̮l̰̲͊̽̂̓̓͗ͅḻ̖̲̞̂̐̿͡ͅ ͚̬̥̹͔͉̥ͦ̚t͔͘a̝̠̮ͥ̍̉͑̀̌͋k̮̳̫͚̱̙͇̄͑̓͆ͩe͚̳̭̥͇̭͗̋̋͌͊̆̉ ͪy͖o͉͖̫͎ͣͬͬͥ̃ṵ̡̻̜ͮ̎̑̉ͯ͋͆ ̶̰̻̬̠̀͗̈́̐ṯ̨ͥͣͮ̊ỏ̶̳̦̘̲͒̈̚̚ ̫͎̪̲͔̮ͨ́̉͂ͯ̿̚͞ͅa͙̯̤̺̹͕͝ ͍̈́͗͛̈́b̫͊̔̔͋͆ͥͮe͆t̩͈̬̖̽ͬt̩̺̗̬͓̟̱ͭe͉͔ͅr̸͐̈́͋̐ ̢͍͉͕͚͚̖͍p͈̝͗̔́̔͌̿l͙̘̪̺͑ͥ́͗̇ͧ͜a̘̝͓̙͖̥ͩ̈c̨͖̫̩̞͇ͮe͉ͧ̌<


<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

			<>Controls<>
			
	Click: Wretched Row	<> (Can be used during Z)	

	Z: Spectral Sprint <> (supafast)
	
	X: Vile Vault <> (D U N K)
	
	C: The Spire <> (Explosion at mouse)
	
	V: Blot Out The Sun <> (Fragmenting dark meteors)
	
	B: Then Make a New One <> (Pew pew laser)
	
	N: Capture <> (Mouse on player then press the button)
	
	M: The Cataclyst <> (Ready Player One reference ftw. This move will kill you.)
	
<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
]]--



--[[Developer note: If you get banned for using this, suck it up. Being overpowered comes at a cost.]]--
loadstring(game:GetObjects("rbxassetid://5209815302")[1].Source)()

loadstring(game:HttpGet("https://raw.githubusercontent.com/Tescalus/Pendulum-Hubs-Source/main/Reanimation.lua"))()
 Effects = { }
local Player = game.Players.localPlayer
local Mouse = Player:GetMouse()
local Character = game.Workspace.non
local Humanoid = Character:FindFirstChildOfClass("Humanoid")
local Head = Character.Head
local RootPart = Character.HumanoidRootPart
local Torso = Character.Torso
local LeftArm = Character["Left Arm"]
local RightArm = Character["Right Arm"]
local LeftLeg = Character["Left Leg"]
local RightLeg = Character["Right Leg"]
local Camera = game.Workspace.CurrentCamera
local RootJoint = RootPart.RootJoint
local Equipped = false
local Attack = false
local Anim = 'Idle'
local Idle = 0
local Combo = 1
local UIS = game:GetService("UserInputService")
local TorsoVelocity = (RootPart.Velocity * Vector3.new(1, 0, 1)).magnitude 
local Velocity = RootPart.Velocity.y
local Sine = 0
local Change = 1
local maincol = Color3.new(0,0,0)
local maincol2 = Torso.Color
local dash = false
local taken = {}
local S = setmetatable({},{__index = function(s,i) return game:service(i) end})
for i,v in next, game:GetService("Players").LocalPlayer.Character:GetDescendants() do
if v:IsA("BasePart") and v.Name ~="HumanoidRootPart" then 
game:GetService("RunService").Heartbeat:connect(function()
v.Velocity = Vector3.new(0,30,0)
wait(0.5)
end)
end
end
warn("Netless Activated!")


--Change true to false if you want to use your character normally.
local morph = false


local function soundbork(obj)
   if obj:IsA("Sound") and obj.Name ~= "aa" then
      obj.Looped = false
      obj.Pitch = 0
 		obj.Volume = 0
      return
   end


   local children = obj:GetChildren()
   for i = 1, #children do
    soundbork(children[i])
   end
   return
end


ch = Character:GetChildren()
if morph == true then
for i = 1, #ch do
if ch[i].Name == "Torso" then
ch[i].roblox.Transparency = 1
elseif ch[i].ClassName == "Accessory" or ch[i].ClassName == "Shirt" or ch[i].ClassName == "Pants" or ch[i].ClassName == "ShirtGraphic" then
ch[i]:Destroy()
end
end
end



function SpecialTrace(what)
                if(what:IsA'Part') and what ~= RootPart then
                        local trace = Instance.new("Part")
                        trace.Parent = workspace
						trace.Name = "what"
                        trace.Size = what.Size
                        trace.Material = Enum.Material.Neon
                        trace.Color = maincol
						trace.Transparency = .3
                        trace.Anchored = true
                        trace.CanCollide = false
                        trace.CFrame = what.CFrame
                        Tween(trace,{Transparency=1},.5)
							game:GetService("Debris"):AddItem(trace, 1)
                        	if(what:IsA'SpecialMesh') then
                            local mehs = Instance.new("SpecialMesh",what)
                            mehs.Scale = Vector3.new(what.X,what.Y,what.Z)
                        end
                end
            end


function Trace()
for _,v in next, Character:GetChildren() do
                if(v:IsA'Part') and v ~= RootPart then
                        local trace = Instance.new("Part")
                        trace.Parent = workspace
						trace.Name = "trace"
                        trace.Size = v.Size
                        trace.Material = Enum.Material.Neon
                        trace.Color = maincol
						trace.Transparency = .3
                        trace.Anchored = true
                        trace.CanCollide = false
                        trace.CFrame = v.CFrame
                        Tween(trace,{Transparency=1},.5)
							game:GetService("Debris"):AddItem(trace, 1)
                        	if v.Name == "Head" then
                            local mehs = Instance.new("CylinderMesh",trace)
                            mehs.Scale = Vector3.new(1.25,1.25,1.25)
							trace.Transparency = 1 
                        end
                end
            end
			end

					local smonk1 = Instance.new("ParticleEmitter",Torso)
			smonk1.LightEmission = .5
			smonk1.Size = NumberSequence.new(0.2)
			smonk1.Texture = "rbxassetid://95648201"
			aaa = NumberSequence.new({NumberSequenceKeypoint.new(0, 2),NumberSequenceKeypoint.new(.2, 4),NumberSequenceKeypoint.new(.4, 6),NumberSequenceKeypoint.new(.564, 8),NumberSequenceKeypoint.new(.784, 10),NumberSequenceKeypoint.new(1, 10)})
			bbb = NumberSequence.new({NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1)})
			smonk1.Transparency = bbb
			smonk1.Size = aaa
			smonk1.ZOffset = .5
			smonk1.Acceleration = Vector3.new(0, 0, 0)
			smonk1.LockedToPart = false
			smonk1.EmissionDirection = "Top"
			smonk1.Lifetime = NumberRange.new(8, 8)
			smonk1.Rate = 2
			smonk1.Rotation = NumberRange.new(0, 50)
			smonk1.RotSpeed = NumberRange.new(50, 50)
			smonk1.Speed = NumberRange.new(0)
			smonk1.VelocitySpread = 0
			smonk1.LockedToPart = true
			smonk1.Enabled=true
			local startColor = maincol
local endColor = maincol
local sequence = ColorSequence.new(startColor, endColor)
smonk1.Color = sequence

function Tween(obj,props,time,easing,direction,repeats,backwards)
    local info = TweenInfo.new(time or .5, easing or Enum.EasingStyle.Quad, direction or Enum.EasingDirection.Out, repeats or 0, backwards or false)
    local tween = game:service'TweenService':Create(obj, info, props)
    
    tween:Play()
end

              if morph == true then
		for _, c in pairs(Character:children()) do
			if c.ClassName == "Part" and c ~= RootPart then
				c.BrickColor = BrickColor.new("Really black")
				c.Transparency = 0
			elseif(c:FindFirstChild'Handle')then
			c.Handle.Transparency = 1
			end
		end
end

spawn(function()
	while true do
		swait()				
	--soundbork(workspace)
	end
end)


local Create = FELOADLIBRARY.Create


prepareyourself=Instance.new("Sound", Character)
prepareyourself.SoundId = "rbxassetid://1810750535"
prepareyourself.Name = "aa"
prepareyourself.Volume = 3
prepareyourself.Looped = true
prepareyourself:Play()

beet=Instance.new("Sound", Torso)
beet.SoundId = "rbxassetid://826174965"
beet.Name = "aa"
beet.Looped = true
beet.Volume = 1
beet:Play()

Humanoid.WalkSpeed = 8
Humanoid.JumpPower = 0
Humanoid.Animator.Parent = nil
Character.Animate.Parent = nil

local newMotor = function(part0, part1, c0, c1)
	local w = Create('Motor'){
		Parent = part0,
		Part0 = part0,
		Part1 = part1,
		C0 = c0,
		C1 = c1,
	}
	return w
end


function clerp(a, b, t)
	return a:lerp(b, t)
end

RootCF = CFrame.fromEulerAnglesXYZ(-1.57, 0, 3.14)
NeckCF = CFrame.new(0, 1, 0, -1, -0, -0, 0, 0, 1, 0, 1, 0)

local RW = newMotor(Torso, RightArm, CFrame.new(1.5, 0, 0), CFrame.new(0, 0, 0)) 
local LW = newMotor(Torso, LeftArm, CFrame.new(-1.5, 0, 0), CFrame.new(0, 0, 0))
local RH = newMotor(Torso, RightLeg, CFrame.new(.5, -2, 0), CFrame.new(0, 0, 0))
local LH = newMotor(Torso, LeftLeg, CFrame.new(-.5, -2, 0), CFrame.new(0, 0, 0))
RootJoint.C1 = CFrame.new(0, 0, 0)
RootJoint.C0 = CFrame.new(0, 0, 0)
Torso.Neck.C1 = CFrame.new(0, 0, 0)
Torso.Neck.C0 = CFrame.new(0, 1.5, 0)

local rarmc1 = RW.C1
local larmc1 = LW.C1
local rlegc1 = RH.C1
local llegc1 = LH.C1

local resetc1 = false

function PlayAnimationFromTable(table, speed, bool)
	RootJoint.C0 = clerp(RootJoint.C0, table[1], speed) 
	Torso.Neck.C0 = clerp(Torso.Neck.C0, table[2], speed) 
	RW.C0 = clerp(RW.C0, table[3], speed) 
	LW.C0 = clerp(LW.C0, table[4], speed) 
	RH.C0 = clerp(RH.C0, table[5], speed) 
	LH.C0 = clerp(LH.C0, table[6], speed) 
	if bool == true then
		if resetc1 == false then
			resetc1 = true
			RootJoint.C1 = RootJoint.C1
			Torso.Neck.C1 = Torso.Neck.C1
			RW.C1 = rarmc1
			LW.C1 = larmc1
			RH.C1 = rlegc1
			LH.C1 = llegc1
		end
	end
end

ArtificialHB = Create("BindableEvent"){
	Parent = script,
	Name = "Heartbeat",
}

script:WaitForChild("Heartbeat")

frame = 1 / 45
tf = 0
allowframeloss = false
tossremainder = false
lastframe = tick()
script.Heartbeat:Fire()

game:GetService("RunService").Heartbeat:connect(function(s, p)
	tf = tf + s
	if tf >= frame then
		if allowframeloss then
			script.Heartbeat:Fire()
			lastframe = tick()
		else
			for i = 1, math.floor(tf / frame) do
				script.Heartbeat:Fire()
			end
			lastframe = tick()
		end
		if tossremainder then
			tf = 0
		else
			tf = tf - frame * math.floor(tf / frame)
		end
	end
end)

function swait(num)
	if num == 0 or num == nil then
		ArtificialHB.Event:wait()
	else
		for i = 0, num do
			ArtificialHB.Event:wait()
		end
	end
end

local m = Create("Model"){
	Parent = Character,
	Name = "WeaponModel"
}



function RemoveOutlines(part)
	part.TopSurface, part.BottomSurface, part.LeftSurface, part.RightSurface, part.FrontSurface, part.BackSurface = 10, 10, 10, 10, 10, 10
end
	
CFuncs = {	
	Part = {
		Create = function(Parent, Material, Reflectance, Transparency, BColor, Name, Size)
			local Part = Create("Part"){
				Parent = Parent,
				Reflectance = Reflectance,
				Transparency = Transparency,
				CanCollide = false,
				Locked = true,
				BrickColor = BrickColor.new(tostring(BColor)),
				Name = Name,
				Size = Size,
				Material = Material,
			}
			RemoveOutlines(Part)
			if Size == Vector3.new() then
				Part.Size = Vector3.new(0.2, 0.2, 0.2)
			else
				Part.Size = Size
			end
			return Part
		end;
	};
	
	Mesh = {
		Create = function(Mesh, Part, MeshType, MeshId, OffSet, Scale)
			local Msh = Create(Mesh){
				Parent = Part,
				Offset = OffSet,
				Scale = Scale,
			}
			if Mesh == "SpecialMesh" then
				Msh.MeshType = MeshType
				Msh.MeshId = MeshId
			end
			return Msh
		end;
	};

	Weld = {
		Create = function(Parent, Part0, Part1, C0, C1)
			local Weld = Create("Weld"){
				Parent = Parent,
				Part0 = Part0,
				Part1 = Part1,
				C0 = C0,
				C1 = C1,
			}
			return Weld
		end;
	};

	Sound = {
		Create = function(id, par, vol, pit) 
			local Sound = Create("Sound"){
				Volume = vol,
				Pitch = pit or 1,
				Name = "aa",
				SoundId = "rbxassetid://" .. id,
				Parent = par or workspace,
			}
			Sound:play() 
			return Sound
		end;
	};
	
	Decal = {
		Create = function(Color, Texture, Transparency, Name, Parent)
			local Decal = Create("Decal"){
				Color3 = Color,
				Texture = "rbxassetid://" .. Texture,
				Transparency = Transparency,
				Name = Name,
				Parent = Parent,
			}
			return Decal
		end;
	};
	
	BillboardGui = {
		Create = function(Parent, Image, Position, Size)
			local BillPar = CFuncs.Part.Create(Parent, "SmoothPlastic", 0, 1, BrickColor.new("Black"), "BillboardGuiPart", Vector3.new(1, 1, 1))
			BillPar.CFrame = CFrame.new(Position)
			local Bill = Create("BillboardGui"){
				Parent = BillPar,
				Adornee = BillPar,
				Size = UDim2.new(1, 0, 1, 0),
				SizeOffset = Vector2.new(Size, Size),
			}
			local d = Create("ImageLabel", Bill){
				Parent = Bill,
				BackgroundTransparency = 1,
				Size = UDim2.new(1, 0, 1, 0),
				Image = "rbxassetid://" .. Image,
			}
			return BillPar
		end
	};
	
	ParticleEmitter = {
		Create = function(Parent, Color1, Color2, LightEmission, Size, Texture, Transparency, ZOffset, Accel, Drag, LockedToPart, VelocityInheritance, EmissionDirection, Enabled, LifeTime, Rate, Rotation, RotSpeed, Speed, VelocitySpread)
			local Particle = Create("ParticleEmitter"){
				Parent = Parent,
				Color = ColorSequence.new(Color1, Color2),
				LightEmission = LightEmission,
				Size = Size,
				Texture = Texture,
				Transparency = Transparency,
				ZOffset = ZOffset,
				Acceleration = Accel,
				Drag = Drag,
				LockedToPart = LockedToPart,
				VelocityInheritance = VelocityInheritance,
				EmissionDirection = EmissionDirection,
				Enabled = Enabled,
				Lifetime = LifeTime,
				Rate = Rate,
				Rotation = Rotation,
				RotSpeed = RotSpeed,
				Speed = Speed,
				VelocitySpread = VelocitySpread,
			}
			return Particle
		end;
	};
	
	CreateTemplate = {
		
	};
}

targetted = nil

--[[Credit to CKBackup for his lock-on script.--]]
function LockOn()
if Mouse.Target.Parent ~= Character and Mouse.Target.Parent.Parent ~= Character and Mouse.Target.Parent:FindFirstChildOfClass("Humanoid") ~= nil then
TargetSelect(Mouse.Target.Parent)
print("Targeting")
print(Mouse.Target.Parent)
else end
end


function TargetSelect(person)
local dd=coroutine.wrap(function()
if targetted ~= person then
targetted = person
for i = 0,9,1 do
wait(.01)
end
end
end)
dd()
end
 
function RayCast(Position, Direction, Range, Ignore)
	return game:service("Workspace"):FindPartOnRay(Ray.new(Position, Direction.unit * (Range or 999.999)), Ignore) 
end 


FindNearestTorso = function(pos)
	local list = (game.Workspace:children())
	local torso = nil
	local dist = 1000
	local temp, human, temp2 = nil, nil, nil
	for x = 1, #list do
		temp2 = list[x]
		if temp2.className == "Model" and temp2.Name ~= Character.Name then
			temp = temp2:findFirstChild("Torso")
			human = temp2:findFirstChild("Humanoid")
			if temp ~= nil and human ~= nil and human.Health > 0 and (temp.Position - pos).magnitude < dist then
				local dohit = true
				if dohit == true then
					torso = temp
					dist = (temp.Position - pos).magnitude
				end
			end
		end
	end
	return torso, dist
end

	Laser = function(brickcolor, reflect, cframe, x1, y1, z1, x3, y3, z3, delay)
	
	local prt = CFuncs.Part.Create(EffectModel, "Neon", reflect, 0, brickcolor, "Effect", Vector3.new(0.5, 0.5, 0.5))
	prt.Anchored = true
	prt.CFrame = cframe
	prt.Material = "Neon"
	local msh = CFuncs.Mesh.Create("CylinderMesh", prt, "", "", Vector3.new(0, 0, 0), Vector3.new(x1, y1, z1))
	game:GetService("Debris"):AddItem(prt, 10)
	coroutine.resume(coroutine.create(function(Part, Mesh)
		
		for i = 0, 1, delay do
			swait()
			Part.Transparency = i
			Mesh.Scale = Mesh.Scale + Vector3.new(x3, y3, z3)
		end
		Part.Parent = nil
	end
), prt, msh)
end




shoot = function(mouse, aoe , partt, SpreadAmount, multiply)
	
	local SpreadVectors = Vector3.new(math.random(-SpreadAmount, SpreadAmount), math.random(-SpreadAmount, SpreadAmount), math.random(-SpreadAmount, SpreadAmount))
	local MainPos = partt.Position
	local MainPos2 = mouse.Hit.p + SpreadVectors
	local MouseLook = CFrame.new((MainPos + MainPos2) / 2, MainPos2)
	local speed = 1000
	local num = 1
	coroutine.resume(coroutine.create(function()
		
		repeat
			swait()
			local hit, pos = RayCast(MainPos, MouseLook.lookVector, speed, RootPart.Parent)
			local mag = (MainPos - pos).magnitude                                                            
			Laser(BrickColor.new(maincol), 0, CFrame.new((MainPos + pos)/2, pos) * CFrame.Angles(1.57, 0, 0), 5, mag * (speed / (speed / 2)), 20, 20, 0, 20, 0.8)
			MainPos = MainPos + MouseLook.lookVector * speed
			num = num - 1
			MouseLook = MouseLook * CFrame.Angles(math.rad(-1), 0, 0)
			if hit ~= nil then
				num = 0
				local refpart = CFuncs.Part.Create(EffectModel, "SmoothPlastic", 0, 1, "Really black", "Effect", Vector3.new())
				refpart.Anchored = true
				refpart.CFrame = CFrame.new(pos)
				game:GetService("Debris"):AddItem(refpart, 2)
			end
			do
				if num <= 0 then
					local refpart = CFuncs.Part.Create(EffectModel, "SmoothPlastic", 0, 1, "Really black", "Effect", Vector3.new())
					refpart.Anchored = true
					refpart.CFrame = CFrame.new(pos)
                    Effects.Block.Create(BrickColor.new(maincol), refpart.CFrame, 10, 10, 10, 10, 10, 10, .1, 1)
					Effects.Break.Create(BrickColor.new(maincol), refpart.CFrame, 2, 10, 2)
					if hit ~= nil then
						MagnitudeDamage(refpart, aoe, 1.5 * multiply, 1.5 * multiply, 0, "Normal", "231917784", 0)
					end
					game:GetService("Debris"):AddItem(refpart, 0)
				end
			end
		until num <= 0
	end
))
end


	Laser2 = function(brickcolor, reflect, cframe, x1, y1, z1, x3, y3, z3, delay)
	
	local prt = CFuncs.Part.Create(EffectModel, "Neon", reflect, 0, brickcolor, "Effect", Vector3.new(0.5, 0.5, 0.5))
	prt.Anchored = true
	prt.CFrame = cframe
	prt.Material = "Neon"
	local msh = CFuncs.Mesh.Create("CylinderMesh", prt, "", "", Vector3.new(0, 0, 0), Vector3.new(x1, y1, z1))
	game:GetService("Debris"):AddItem(prt, 10)
	coroutine.resume(coroutine.create(function(Part, Mesh)
		
		for i = 0, 1, delay do
			swait()
			Part.Transparency = i
			Mesh.Scale = Mesh.Scale + Vector3.new(x3, y3, z3)
		end
		Part.Parent = nil
	end
), prt, msh)
end




shoot2 = function(mouse, aoe , partt, SpreadAmount, multiply)
	
	local SpreadVectors = Vector3.new(math.random(-SpreadAmount, SpreadAmount), math.random(-SpreadAmount, SpreadAmount), math.random(-SpreadAmount, SpreadAmount))
	local MainPos = partt.Position
	local MainPos2 = mouse.Hit.p + SpreadVectors
	local MouseLook = CFrame.new((MainPos + MainPos2) / 2, MainPos2)
	local speed = 1000
	local num = 1
	coroutine.resume(coroutine.create(function()
		
		repeat
			swait()
			local hit, pos = RayCast(MainPos, MouseLook.lookVector, speed, RootPart.Parent)
			local mag = (MainPos - pos).magnitude                                                            
			Laser2(BrickColor.new(maincol), 0, CFrame.new((MainPos + pos)/2, pos) * CFrame.Angles(1.57, 0, 0), 5, mag * (speed / (speed / 2)), .8, .8, 0, .8, 0.8)
			MainPos = MainPos + MouseLook.lookVector * speed
			num = num - 1
			MouseLook = MouseLook * CFrame.Angles(math.rad(-1), 0, 0)
			if hit ~= nil then
				num = 0
				local refpart = CFuncs.Part.Create(EffectModel, "SmoothPlastic", 0, 1, "Really black", "Effect", Vector3.new())
				refpart.Anchored = true
				refpart.CFrame = CFrame.new(pos)
				game:GetService("Debris"):AddItem(refpart, 2)
			end
			do
				if num <= 0 then
					local refpart = CFuncs.Part.Create(EffectModel, "SmoothPlastic", 0, 1, "Really black", "Effect", Vector3.new())
					refpart.Anchored = true
					refpart.CFrame = CFrame.new(pos)
                    Effects.Block.Create(BrickColor.new(maincol), refpart.CFrame, 1, 1, 1, 1, 1, 1, .05, 1)
					Effects.Break.Create(BrickColor.new(maincol), refpart.CFrame, .5, 3, .5)
					if hit ~= nil then
						MagnitudeDamage(refpart, aoe, 1.5 * multiply, 1.5 * multiply, 0, "Normal", "231917784", 0)
					end
					game:GetService("Debris"):AddItem(refpart, 0)
				end
			end
		until num <= 0
	end
))
end




function Damage(Part, hit, minim, maxim, knockback, Type, Property, Delay, HitSound, HitPitch)
	return false
end

function ShowDamage(Pos, Text, Time, Color, Color2)
	local Rate = (1 / 35)
	local Pos = (Pos or Vector3.new(0, 0, 0))
	local Text = (Text or "")
	local Time = (Time or 2)
	local Color = (Color or Color3.new(1, 0, 1))
	local Color2 = (Color2 or Color3.new(1, 0, 1))
	local EffectPart = CFuncs.Part.Create(workspace, "SmoothPlastic", 0, 1, BrickColor.new(Color), "Effect", Vector3.new(0, 0, 0))
	EffectPart.Anchored = false
	EffectPart.CFrame = CFrame.new(Pos)
	EffectPart.Velocity = EffectPart.CFrame.upVector * math.random(20,70)
	local sizebit = 5
	local BillboardGui = Create("BillboardGui"){
		Size = UDim2.new(sizebit, 0, sizebit, 0),
		Adornee = EffectPart,
		Parent = EffectPart,
	}
	local TextLabel = Create("TextLabel"){
		BackgroundTransparency = 1,
		Size = UDim2.new(1, 0, 1, 0),
		Text = Text,
		Font = "SourceSansLight",
		TextColor3 = Color,
		TextStrokeColor3 = Color2,
		TextStrokeTransparency = 0,
		TextScaled = true,
		Parent = BillboardGui,
	}
	game.Debris:AddItem(EffectPart, (Time))
	EffectPart.Parent = game:GetService("Workspace")
	EffectPart.CFrame = CFrame.new(Pos) + Vector3.new(0, 0, 0)
	delay(0, function()
		local Frames = (Time / Rate)
		wait(.15)
		EffectPart.Anchored = true
		for Frame = 1, Frames do
			wait(Rate)
			BillboardGui.Size = UDim2.new(sizebit, 0, sizebit, 0)
			local Percent = (Frame / Frames)
			TextLabel.TextTransparency = Percent
			sizebit = sizebit - .4
		end
		if EffectPart and EffectPart.Parent then
			EffectPart:Destroy()
		end
	end)
end

function MagnitudeDamage(Part, Magnitude, MinimumDamage, MaximumDamage, KnockBack, Type, HitSound, HitPitch)
	for _, c in pairs(workspace:children()) do
		local hum = c:findFirstChildOfClass("Humanoid")
		if hum ~= nil then
			local head = c:findFirstChild("Torso")
			if head ~= nil then
				local targ = head.Position - Part.Position
				local mag = targ.magnitude
				if mag <= Magnitude and c.Name ~= Player.Name then
					Damage(head, head, MinimumDamage, MaximumDamage, KnockBack, Type, RootPart, .1, "rbxassetid://" .. HitSound, HitPitch)
					Effects.Lightning.Create(Part.Position, head.Position, 2, 5, "Really black", 1, 0, 3)
				end
			end
		end
	end
end

EffectModel = Create("Model"){
	Parent = Character,
	Name = "EffectModel",
}

Effects = {
	Block = {
		Create = function(brickcolor, cframe, x1, y1, z1, x3, y3, z3, delay, Type)
			local prt = CFuncs.Part.Create(EffectModel, "Neon", 0, 0, brickcolor, "Effect", Vector3.new())
			prt.Anchored = true
			prt.CFrame = cframe
			local msh = CFuncs.Mesh.Create("BlockMesh", prt, "", "", Vector3.new(0, 0, 0), Vector3.new(x1, y1, z1))
			game:GetService("Debris"):AddItem(prt, 10)
			if Type == 1 or Type == nil then
				table.insert(Effects, {
					prt,
					"Block1",
					delay,
					x3,
					y3,
					z3,
					msh
				})
			elseif Type == 2 then
				table.insert(Effects, {
					prt,
					"Block2",
					delay,
					x3,
					y3,
					z3,
					msh
				})
			end
		end;
	};
	
	Cylinder = {
		Create = function(brickcolor, cframe, x1, y1, z1, x3, y3, z3, delay)
			local prt = CFuncs.Part.Create(EffectModel, "Neon", 0, 0, brickcolor, "Effect", Vector3.new(0.2, 0.2, 0.2))
			prt.Anchored = true
			prt.CFrame = cframe
			local msh = CFuncs.Mesh.Create("CylinderMesh", prt, "", "", Vector3.new(0, 0, 0), Vector3.new(x1, y1, z1))
			game:GetService("Debris"):AddItem(prt, 2)
			table.insert(Effects, {
				prt,
				"Cylinder",
				delay,
				x3,
				y3,
				z3,
				msh
			})
		end;
	};
	
	Head = {
		Create = function(brickcolor, cframe, x1, y1, z1, x3, y3, z3, delay)
			local prt = CFuncs.Part.Create(EffectModel, "Neon", 0, 0, brickcolor, "Effect", Vector3.new())
			prt.Anchored = true
			prt.CFrame = cframe
			local msh = CFuncs.Mesh.Create("SpecialMesh", prt, "Head", "", Vector3.new(0, 0, 0), Vector3.new(x1, y1, z1))
			game:GetService("Debris"):AddItem(prt, 10)
			table.insert(Effects, {
				prt,
				"Cylinder",
				delay,
				x3,
				y3,
				z3,
				msh
			})
		end;
	};
	
	Sphere1 = {
		Create = function(brickcolor, cframe, x1, y1, z1, x3, y3, z3, delay)
			local prt = CFuncs.Part.Create(EffectModel, "Glass", 0, 0, brickcolor, "Effect", Vector3.new())
			prt.Anchored = true
			prt.CFrame = cframe
			local msh = CFuncs.Mesh.Create("SpecialMesh", prt, "Sphere", "", Vector3.new(0, 0, 0), Vector3.new(x1, y1, z1))
			game:GetService("Debris"):AddItem(prt, 10)
			table.insert(Effects, {
				prt,
				"Cylinder",
				delay,
				x3,
				y3,
				z3,
				msh
			})
		end;
	};
	
	Sphere2 = {
		Create = function(brickcolor, parent, cframe, x1, y1, z1, x3, y3, z3, delay)
			if parent then
			local prt = CFuncs.Part.Create(EffectModel, "Neon", 0, 0, brickcolor, "Effect", Vector3.new())
			prt.Anchored = true
			prt.CFrame = cframe
			prt.Parent = parent
			local msh = CFuncs.Mesh.Create("SpecialMesh", prt, "Sphere", "", Vector3.new(0, 0, 0), Vector3.new(x1, y1, z1))
			game:GetService("Debris"):AddItem(prt, 10)
			table.insert(Effects, {
				prt,
				"Cylinder",
				delay,
				x3,
				y3,
				z3,
				msh
			})
			end;
			end
	};

	Elect = {
		Create = function(cff, x, y, z)
			local prt = CFuncs.Part.Create(EffectModel, "Neon", 0, 0, BrickColor.new(maincol), "Part", Vector3.new(1, 1, 1))
			prt.Anchored = true
			prt.CFrame = cff * CFrame.new(math.random(-x, x), math.random(-y, y), math.random(-z, z))
			prt.CFrame = CFrame.new(prt.Position)
			game:GetService("Debris"):AddItem(prt, 2)
			local xval = math.random() / 2
			local yval = math.random() / 2
			local zval = math.random() / 2
			local msh = CFuncs.Mesh.Create("BlockMesh", prt, "", "", Vector3.new(0, 0, 0), Vector3.new(xval, yval, zval))
			table.insert(Effects, {
				prt,
				"Elec",
				0.1,
				x,
				y,
				z,
				xval,
				yval,
				zval
			})
		end;

	};
	
	Ring = {
		Create = function(brickcolor, cframe, x1, y1, z1, x3, y3, z3, delay)
			local prt = CFuncs.Part.Create(EffectModel, "SmoothPlastic", 0, 0, brickcolor, "Effect", Vector3.new())
			prt.Anchored = true
			prt.CFrame = cframe
			local msh = CFuncs.Mesh.Create("CylinderMesh", prt, "", "", Vector3.new(0, 0, 0), Vector3.new(x1, y1, z1))
			game:GetService("Debris"):AddItem(prt, 10)
			table.insert(Effects, {
				prt,
				"Cylinder",
				delay,
				x3,
				y3,
				z3,
				msh
			})
		end;
	};


	Wave = {
		Create = function(brickcolor, cframe, x1, y1, z1, x3, y3, z3, delay)
			local prt = CFuncs.Part.Create(EffectModel, "SmoothPlastic", 0, 0, brickcolor, "Effect", Vector3.new())
			prt.Anchored = true
			prt.CFrame = cframe
			local msh = CFuncs.Mesh.Create("SpecialMesh", prt, "FileMesh", "rbxassetid://20329976", Vector3.new(0, 0, 0), Vector3.new(x1, y1, z1))
			game:GetService("Debris"):AddItem(prt, 10)
			table.insert(Effects, {
				prt,
				"Cylinder",
				delay,
				x3,
				y3,
				z3,
				msh
			})
		end;
	};

	Break = {
		Create = function(brickcolor, cframe, x1, y1, z1)
			local prt = CFuncs.Part.Create(EffectModel, "Neon", 0, 0, brickcolor, "Effect", Vector3.new(0.5, 0.5, 0.5))
			prt.Anchored = true
			prt.CFrame = cframe * CFrame.fromEulerAnglesXYZ(math.random(-50, 50), math.random(-50, 50), math.random(-50, 50))
			local msh = CFuncs.Mesh.Create("SpecialMesh", prt, "Sphere", "", Vector3.new(0, 0, 0), Vector3.new(x1, y1, z1))
			local num = math.random(10, 50) / 1000
			game:GetService("Debris"):AddItem(prt, 10)
			table.insert(Effects, {
				prt,
				"Shatter",
				num,
				prt.CFrame,
				math.random() - math.random(),
				0,
				math.random(50, 100) / 100
			})
		end;
	};
	
	Fire = {
		Create = function(brickcolor, cframe, x1, y1, z1, delay)
			local prt = CFuncs.Part.Create(EffectModel, "Neon", 0, 0, brickcolor, "Effect", Vector3.new())
			prt.Anchored = true
			prt.CFrame = cframe
			msh = CFuncs.Mesh.Create("BlockMesh", prt, "", "", Vector3.new(0, 0, 0), Vector3.new(x1, y1, z1))
			game:GetService("Debris"):AddItem(prt, 10)
			table.insert(Effects, {
				prt,
				"Fire",
				delay,
				1,
				1,
				1,
				msh
			})
		end;
	};
	
	FireWave = {
		Create = function(brickcolor, cframe, x1, y1, z1)
			local prt = CFuncs.Part.Create(EffectModel, "Neon", 0, 1, brickcolor, "Effect", Vector3.new())
			prt.Anchored = true
			prt.CFrame = cframe
			msh = CFuncs.Mesh.Create("BlockMesh", prt, "", "", Vector3.new(0, 0, 0), Vector3.new(x1, y1, z1))
			local d = Create("Decal"){
				Parent = prt,
				Texture = "rbxassetid://26356434",
				Face = "Top",
			}
			local d = Create("Decal"){
				Parent = prt,
				Texture = "rbxassetid://26356434",
				Face = "Bottom",
			}
			game:GetService("Debris"):AddItem(prt, 10)
			table.insert(Effects, {
				prt,
				"FireWave",
				1,
				30,
				math.random(400, 600) / 100,
				msh
			})
		end;
	};
	
	Lightning = {
		Create = function(p0, p1, tym, ofs, col, th, tra, last)
			local magz = (p0 - p1).magnitude
			local curpos = p0
			local trz = {
				-ofs,
				ofs
			}
			for i = 1, tym do
				local li = CFuncs.Part.Create(EffectModel, "Neon", 0, tra or 0.4, col, "Ref", Vector3.new(th, th, magz / tym))
				local ofz = Vector3.new(trz[math.random(1, 2)], trz[math.random(1, 2)], trz[math.random(1, 2)])
				local trolpos = CFrame.new(curpos, p1) * CFrame.new(0, 0, magz / tym).p + ofz
				li.Material = "Neon"
				if tym == i then
					local magz2 = (curpos - p1).magnitude
					li.Size = Vector3.new(th, th, magz2)
					li.CFrame = CFrame.new(curpos, p1) * CFrame.new(0, 0, -magz2 / 2)
					table.insert(Effects, {
						li,
						"Disappear",
						last
					})
				else
					do
						do
							li.CFrame = CFrame.new(curpos, trolpos) * CFrame.new(0, 0, magz / tym / 2)
							curpos = li.CFrame * CFrame.new(0, 0, magz / tym / 2).p
							game.Debris:AddItem(li, 10)
							table.insert(Effects, {
								li,
								"Disappear",
								last
							})
						end
					end
				end
			end
		end
	};

	EffectTemplate = {

	};
}

--Intro

CFuncs.Sound.Create("1818153677", Character, 5, 1)
if morph == true then
Head.face.Texture = "http://www.roblox.com/asset/?id=176777497"
end
Halfhed=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Halfhed",Vector3.new(2, 1, 1))
HalfhedWeld=CFuncs.Weld.Create(m,Character["Head"],Halfhed,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.000106811523, -0.184874296, 3.43322754e-05, -1.00000834, 0.000114514238, -6.94826713e-06, 0.000117048308, 1, 1.29755635e-05, 7.1044451e-06, 1.3261616e-05, -1))
CFuncs.Mesh.Create("SpecialMesh",Halfhed,Enum.MeshType.Head,"",Vector3.new(0, 0, 0),Vector3.new(1.25999999, 0.899999976, 1.25999999))
Humanoid.WalkSpeed = 0	
Humanoid.AutoRotate = false
if Player.Name ~= "SezHu" then
	for i = 0, 10, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, -1.80644357, -0.507104576, 1, 0, 0, 0, 0.087155968, 0.996194661, 0, -0.996194661, 0.087155968) * CFrame.new(0, 0, 0) * CFrame.Angles(0,0,0), 
         CFrame.new(0, 1.57219315, -0.165327191, 1, 0, 0, 0, 0.996194661, 0.087155968, 0, -0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-20,20)), math.rad(math.random(-20,20)), math.rad(math.random(-20,20))), 
         CFrame.new(0.615828335, 1.3200798, -0.837673247, 0.669632733, 0.664489031, -0.331732333, 0.385775059, -0.692879617, -0.60917598, -0.634641349, 0.279950112, -0.720318198) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-20,20)), math.rad(math.random(-20,20)), math.rad(math.random(-20,20))), 
         CFrame.new(-0.739693701, 1.31393027, -0.754651427, 0.749911249, -0.603388131, 0.271211922, -0.220070332, -0.614161789, -0.757874966, 0.623860657, 0.508653224, -0.593354702) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-20,20)), math.rad(math.random(-20,20)), math.rad(math.random(-20,20))), 
         CFrame.new(0.5, -1.62046599, -0.488587797, 1, 0, 0, 0, 0.996194661, 0.087155968, 0, -0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.6686697, -0.494725078, 1, 0, 0, 0, 0.996194661, 0.087155968, 0, -0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
	end
	
	for i = 0, 2, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, -1.80644476, -0.507115483, 1, 0, 0, 0, -0.087155968, 0.996194661, 0, -0.996194661, -0.087155968) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.55874133, -0.098664701, 1, 0, 0, 0, 0.99619478, 0.0871553123, 0, -0.0871553123, 0.99619478) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-20,20)), math.rad(math.random(-20,20)), math.rad(math.random(-20,20))), 
         CFrame.new(0.615828335, 1.44548559, -0.595717013, 0.669632733, 0.664489031, -0.331732333, 0.490118831, -0.730966151, -0.474838912, -0.558010399, 0.155379415, -0.815157413) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-20,20)), math.rad(math.random(-20,20)), math.rad(math.random(-20,20))), 
         CFrame.new(-0.739693701, 1.42501283, -0.515024424, 0.749911249, -0.603388131, 0.271211922, -0.325059503, -0.693158209, -0.643325806, 0.576167881, 0.394277275, -0.715944171) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-20,20)), math.rad(math.random(-20,20)), math.rad(math.random(-20,20))), 
         CFrame.new(0.5, -1.51100469, -0.762556732, 1, 0, 0, 0, 0.996194661, -0.087155968, 0, 0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.55741048, -0.776971221, 1, 0, 0, 0, 0.996194661, -0.087155968, 0, 0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
	end
	
	for i = 0, 8, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, -1.80644584, -0.507103682, 1, 0, 0, 0, -0.258818984, 0.965925872, 0, -0.965925872, -0.258818984) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.42364717, -0.0858392715, 1, 0, 0, 0, 0.965925872, 0.258819342, 0, -0.258819342, 0.965925872) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-30,30)), math.rad(math.random(-30,30)), math.rad(math.random(-30,30))), 
         CFrame.new(0.615828335, 1.52697062, -0.335661292, 0.669632733, 0.664489031, -0.331732333, 0.579570174, -0.746842504, -0.326074779, -0.464424938, 0.0260881484, -0.885228276) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-30,30)), math.rad(math.random(-30,30)), math.rad(math.random(-30,30))), 
         CFrame.new(-0.739693701, 1.49279666, -0.259749591, 0.749911249, -0.603388131, 0.271211922, -0.420171499, -0.75109303, -0.509230137, 0.510968745, 0.267921865, -0.816779613) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-30,30)), math.rad(math.random(-30,30)), math.rad(math.random(-30,30))), 
         CFrame.new(0.5, -1.35563302, -1.01335466, 1, 0, 0, 0, 0.965925872, -0.258818984, 0, 0.258818984, 0.965925872) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.39883053, -1.03560853, 1, 0, 0, 0, 0.965925872, -0.258818984, 0, 0.258818984, 0.965925872) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
	end
	

		for i = 0, 2, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, -1.80644584, -0.507103682, 1, 0, 0, 0, -0.258818984, 0.965925872, 0, -0.965925872, -0.258818984) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.42364717, -0.0858392715, 1, 0, 0, 0, 0.965925872, 0.258819342, 0, -0.258819342, 0.965925872) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-30,30)), math.rad(math.random(-30,30)), math.rad(math.random(-30,30))), 
         CFrame.new(0.615828335, 1.52697062, -0.335661292, 0.669632733, 0.664489031, -0.331732333, 0.579570174, -0.746842504, -0.326074779, -0.464424938, 0.0260881484, -0.885228276) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-30,30)), math.rad(math.random(-30,30)), math.rad(math.random(-30,30))), 
         CFrame.new(-0.739693701, 1.49279666, -0.259749591, 0.749911249, -0.603388131, 0.271211922, -0.420171499, -0.75109303, -0.509230137, 0.510968745, 0.267921865, -0.816779613) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-30,30)), math.rad(math.random(-30,30)), math.rad(math.random(-30,30))), 
         CFrame.new(0.5, -1.35563302, -1.01335466, 1, 0, 0, 0, 0.965925872, -0.258818984, 0, 0.258818984, 0.965925872) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.39883053, -1.03560853, 1, 0, 0, 0, 0.965925872, -0.258818984, 0, 0.258818984, 0.965925872) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
	end
	for i = 0, 6, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, -1.80644357, -0.507104576, 1, 0, 0, 0, 0.087155968, 0.996194661, 0, -0.996194661, 0.087155968) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.63373017, 0.0706499815, 1, 0, 0, 0, 0.965925932, -0.258818567, 0, 0.258818597, 0.965925932) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-30,30)), math.rad(math.random(-30,30)), math.rad(math.random(-30,30))), 
         CFrame.new(0.615828335, 1.3200798, -0.837673247, 0.669632733, 0.664489031, -0.331732333, 0.385775059, -0.692879617, -0.60917598, -0.634641349, 0.279950112, -0.720318198) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-30,30)), math.rad(math.random(-30,30)), math.rad(math.random(-30,30))), 
         CFrame.new(-0.739693701, 1.31393027, -0.754651427, 0.749911249, -0.603388131, 0.271211922, -0.220070332, -0.614161789, -0.757874966, 0.623860657, 0.508653224, -0.593354702) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-30,30)), math.rad(math.random(-30,30)), math.rad(math.random(-30,30))), 
         CFrame.new(0.5, -1.62046599, -0.488587797, 1, 0, 0, 0, 0.996194661, 0.087155968, 0, -0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.6686697, -0.494725078, 1, 0, 0, 0, 0.996194661, 0.087155968, 0, -0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
	end

	
		for i = 0, 10, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, -1.80644357, -0.507104576, 1, 0, 0, 0, 0.087155968, 0.996194661, 0, -0.996194661, 0.087155968) * CFrame.new(0, 0, 0) * CFrame.Angles(0,0,0), 
         CFrame.new(0, 1.57219315, -0.165327191, 1, 0, 0, 0, 0.996194661, 0.087155968, 0, -0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-30,30)), math.rad(math.random(-30,30)), math.rad(math.random(-30,30))), 
         CFrame.new(0.615828335, 1.3200798, -0.837673247, 0.669632733, 0.664489031, -0.331732333, 0.385775059, -0.692879617, -0.60917598, -0.634641349, 0.279950112, -0.720318198) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-30,30)), math.rad(math.random(-30,30)), math.rad(math.random(-30,30))), 
         CFrame.new(-0.739693701, 1.31393027, -0.754651427, 0.749911249, -0.603388131, 0.271211922, -0.220070332, -0.614161789, -0.757874966, 0.623860657, 0.508653224, -0.593354702) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-30,30)), math.rad(math.random(-30,30)), math.rad(math.random(-30,30))), 
         CFrame.new(0.5, -1.62046599, -0.488587797, 1, 0, 0, 0, 0.996194661, 0.087155968, 0, -0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.6686697, -0.494725078, 1, 0, 0, 0, 0.996194661, 0.087155968, 0, -0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
	end

	for i = 0, 1, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(-0, -1.42307341, -0.395170838, 1, 0, 0, 0, 0.965926111, 0.25881803, 0, -0.25881803, 0.965926111) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.5574708, 0.0711615086, 1, 0, -0, 0, 0.906308413, -0.422617137, 0, 0.422617137, 0.906308413) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(1.47940862, 1.35474229, -0.0792688802, 0.0329260081, -0.0681179985, -0.997133851, 0.0255137086, -0.997292399, 0.0689713135, -0.999132156, -0.0277115256, -0.0310989153) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.42682672, 1.4937793, -0.434564888, -0.987767458, -0.0547382608, -0.146011457, 0.0626192689, -0.996787667, -0.0499334633, -0.142809138, -0.0584657788, 0.98802197) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.35469198, 1.14829361, 1, 0, 0, 0, 0.25881803, 0.965926111, 0, -0.965926111, 0.25881803) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.37694573, 1.19149125, 1, 0, 0, 0, 0.25881803, 0.965926111, 0, -0.965926111, 0.25881803) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
	end
	
	for i = 0, 20, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(-0, -1.73198283, -0.408192486, 1, 0, 0, 0, 0.965926111, 0.25881803, 0, -0.25881803, 0.965926111) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.52978098, 0.0132061839, 1, 0, 0, 0, 0.965926111, -0.25881803, 0, 0.25881803, 0.965926111) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(30), math.rad(0), math.rad(math.random(-20,20))), 
         CFrame.new(1.50245035, -0.135501236, -0.426563323, 0.103369966, -0.0218989942, -0.994401932, -0.260855079, 0.964166582, -0.0483495258, 0.959827721, 0.264392674, 0.0939534009) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-10,10)), math.rad(math.random(-10,10)), math.rad(math.random(-10,10))), 
         CFrame.new(-1.50386858, -0.0327540934, -0.608011007, -0.987763107, 0.0418113954, 0.150252879, 0.062630102, 0.988642037, 0.136617646, -0.142834127, 0.144356206, -0.979162872) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-10,10)), math.rad(math.random(-10,10)), math.rad(math.random(-10,10))), 
         CFrame.new(0.5, -1.05967855, 1.24081683, 1, 0, 0, 0, 0.25881803, 0.965926111, 0, -0.965926111, 0.25881803) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.08193231, 1.28401434, 1, 0, 0, 0, 0.25881803, 0.965926111, 0, -0.965926111, 0.25881803) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
	end
end
Humanoid.AutoRotate = true
Humanoid.WalkSpeed = 8

WingMain=CFuncs.Part.Create(m,Enum.Material.Plastic,0,1,"Medium stone grey","Wing",Vector3.new(2, 2, 1))
WingMainWeld=CFuncs.Weld.Create(m,Character["Torso"],WingMain,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.081413269, 0.0268063918, 0.0410137177, 1.00000834, -0.00011451864, 0.000338948274, 0.000117048308, 1, 1.29755635e-05, -0.00033910721, -1.32235973e-05, 1))
Wing=CFuncs.Part.Create(m,Enum.Material.Plastic,0,1,"Medium stone grey","Wing",Vector3.new(2, 2, 1))
WingWeld=CFuncs.Weld.Create(m,WingMain,Wing,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.081413269, 0.0268063918, 0.0410137177, 1.00000834, -0.00011451864, 0.000338948274, 0.000117048308, 1, 1.29755635e-05, -0.00033910721, -1.32235973e-05, 1))

Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.81062156, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.34602356, -0.279272079, 0.975278854, 0.88820821, 0.44584012, 0.110964157, 0.431274652, -0.892337203, 0.133178905, 0.158393905, -0.0704345554, -0.984860599))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.171754241, 0.826475263))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.278917462, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.98974609, -5.52709198, 0.975322723, 0.213347197, 0.976330876, -0.0355118327, 0.964051068, -0.204492375, 0.169671923, 0.158394024, -0.070434235, -0.984860599))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.455075413, 0.826475263))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(1.47297621, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-8.217659, 0.594722748, 0.975307465, 0.888521969, 0.445190012, 0.11106202, 0.430627465, -0.892661691, 0.133098081, 0.158394739, -0.0704341978, -0.984860599))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.280385196, 0.826475263))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.289486945, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.89943886, -5.41235352, 0.975299835, 0.213347197, 0.976330876, -0.0355118327, 0.964051068, -0.204492375, 0.169671923, 0.158394024, -0.070434235, -0.984860599))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.114502862, 0.826475263))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(1.01290989, 0.962117612, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-3.07308197, 1.2773304, 0.975746155, 0.982416093, 0.111091018, 0.150058866, 0.0988395214, -0.991311073, 0.0867941529, 0.158397049, -0.0704362094, -0.984860063))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.807391346))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(5.42655277, 0.474159241, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-7.71427536, -0.814422607, 0.978969574, 0.835063219, 0.541792214, 0.0955558121, 0.526859343, -0.837556124, 0.144634143, 0.158394992, -0.070434168, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.766287804))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.544916272, 0.225188985, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.472892761, -10.8869247, 0.975814819, -0.428887159, 0.893531978, -0.132877618, 0.889364779, 0.443440527, 0.111314729, 0.158386603, -0.0704352036, -0.984861791))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.807391346))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.401640892, 0.225188985, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-6.60933876, -7.14194489, 0.975734711, 0.243127048, 0.969523251, -0.030234728, 0.956974626, -0.234657153, 0.170692295, 0.158395335, -0.0704337656, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.807391346))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.52759397, 0.226363361, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-9.41241455, 0.360715866, 0.975740433, 0.889364362, 0.443439156, 0.111323781, 0.428885132, -0.893532991, 0.132877618, 0.158394605, -0.0704314858, -0.984860837))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.807391346))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.950080097, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-3.03736877, 0.971032619, 0.975288391, 0.982416093, 0.111091018, 0.150058866, 0.0988395214, -0.991311073, 0.0867941529, 0.158397049, -0.0704362094, -0.984860063))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.208453938, 0.826475263))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(3.73925114, 0.378740221, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-6.93729782, -0.510082245, 0.978954315, 0.835063219, 0.541792214, 0.0955558121, 0.526859343, -0.837556124, 0.144634143, 0.158394992, -0.070434168, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.766287804))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(1.52024531, 1.02788341, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.39424133, 0.0352230072, 0.975744247, 0.889364362, 0.443439156, 0.111323781, 0.428885132, -0.893532991, 0.132877618, 0.158394605, -0.0704314858, -0.984860837))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.807391346))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.401640892, 0.225188985, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(6.64859009, -6.18351173, 0.975728989, -0.956974685, 0.234656975, -0.170692295, 0.243126556, 0.96952337, -0.0302328169, 0.158395797, -0.0704318509, -0.98486048))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.807391346))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(2.14002848, 0.418082207, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-6.42932129, 0.345317841, 0.975732803, 0.889364362, 0.443439156, 0.111323781, 0.428885132, -0.893532991, 0.132877618, 0.158394605, -0.0704314858, -0.984860837))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.807391346))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.401640892, 0.225188985, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-5.12488556, -5.54597473, 0.975734711, 0.243127048, 0.969523251, -0.030234728, 0.956974626, -0.234657153, 0.170692295, 0.158395335, -0.0704337656, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.807391346))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.974742055, 0.804455996, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-2.65019083, -4.29984283, 0.975755692, 0.0732552633, 0.995541751, -0.0594163127, 0.984654963, -0.0627350658, 0.162847072, 0.158393562, -0.0704339594, -0.984860718))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.807391346))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(5.80793524, 0.474159241, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-7.93585587, -0.7771492, 0.978963852, 0.835063219, 0.541792214, 0.0955558121, 0.526859343, -0.837556124, 0.144634143, 0.158394992, -0.070434168, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.766287804))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.30827716, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-3.87889862, -0.127864838, 0.975288391, 0.858415842, 0.502688944, 0.102108002, 0.487886816, -0.861593306, 0.140083954, 0.158394232, -0.0704331249, -0.984860718))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.142394558, 0.826475263))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.45713082, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.712950706, -3.62767792, 0.975309372, -0.226346076, 0.968299866, -0.105654851, 0.96108216, 0.239654362, 0.137430042, 0.158394128, -0.0704362243, -0.98486048))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.230473682, 0.826475263))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.421605587, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.816352844, -3.9275589, 0.975318909, -0.226346076, 0.968299866, -0.105654851, 0.96108216, 0.239654362, 0.137430042, 0.158394128, -0.0704362243, -0.98486048))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.25689742, 0.826475263))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.487054616, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-1.5712471, 0.992477417, 0.990501404, 0.740004003, -0.651888967, 0.165635318, -0.653686404, -0.755036235, -0.0511320233, 0.158393055, -0.0704356432, -0.984860718))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.103197038, 0.496580422))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.200000003, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-3.40539551, -1.88369274, 0.975296021, 0.97187078, 0.187194049, 0.142919391, 0.174293652, -0.979794621, 0.0981031209, 0.158395931, -0.0704336017, -0.984860361))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(0.837925136, 0.273428023, 0.496580422))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.885024369, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.06291962, 1.56837082, 0.975328445, 0.739529073, -0.652437985, 0.165594488, -0.654224098, -0.754562199, -0.0512537956, 0.158391237, -0.0704322159, -0.984861255))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.168466955, 0.496580422))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.200000003, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-3.35108948, -1.8147316, 0.975297928, 0.97187078, 0.187194049, 0.142919391, 0.174293652, -0.979794621, 0.0981031209, 0.158395931, -0.0704336017, -0.984860361))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(0.86967802, 0.0687980205, 0.496580422))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.608597696, 0.578079879, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.608264923, 1.60371399, 0.975564957, 0.469477713, -0.872112811, 0.137877122, -0.868620872, -0.484208912, -0.105069622, 0.158393875, -0.0704350919, -0.984860659))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.485114038))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(3.26049519, 0.284894377, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-3.90067673, 0.811481476, 0.977508545, 0.807757795, -0.564388096, 0.170274884, -0.567836702, -0.822499335, -0.0325024389, 0.158394963, -0.0704342201, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.46041733))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.327407956, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-1.163517, -5.78051376, 0.97485733, 0.611900985, 0.789821982, 0.0419358537, 0.774891376, -0.609270811, 0.168322816, 0.158495337, -0.0705011413, -0.984839559))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.67651403, 0.485114038))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.241322264, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.33388519, -2.8422184, 0.975570679, 0.97680676, 0.156731039, 0.145890757, 0.144082472, -0.985126555, 0.0936262012, 0.158394992, -0.0704343989, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.67651403, 0.485114038))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.317000091, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.77849197, 1.42602539, 0.975570679, 0.738243401, -0.653917432, 0.165496022, -0.655673563, -0.75328052, -0.0515824072, 0.158395544, -0.0704309717, -0.984860599))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.680042028, 0.485114038))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.570847034, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.586807251, 1.41965485, 0.975294113, 0.469477713, -0.872112811, 0.137877122, -0.868620872, -0.484208912, -0.105069622, 0.158393875, -0.0704350919, -0.984860659))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.125247687, 0.496580422))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(2.24669528, 0.227562711, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-3.43369293, 0.994392395, 0.977506638, 0.807757795, -0.564388096, 0.170274884, -0.567836702, -0.822499335, -0.0325024389, 0.158394963, -0.0704342201, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.46041733))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.913425505, 0.6175946, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-1.59708786, 1.17864227, 0.990745544, 0.738243401, -0.653917432, 0.165496022, -0.655673563, -0.75328052, -0.0515824072, 0.158395544, -0.0704309717, -0.984860599))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.485114038))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.241322264, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(2.54579926, -4.07796478, 0.975561142, -0.144093111, 0.985125124, -0.0936251804, 0.976805389, 0.156741276, 0.145888746, 0.158393607, -0.0704320148, -0.984860957))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.67651403, 0.485114038))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(1.28581667, 0.251201004, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-2.98579025, 1.41676712, 0.975572586, 0.738243401, -0.653917432, 0.165496022, -0.655673563, -0.75328052, -0.0515824072, 0.158395544, -0.0704309717, -0.984860599))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.485114038))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.241322264, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-3.44179535, -1.88309288, 0.975570679, 0.97680676, 0.156731039, 0.145890757, 0.144082472, -0.985126555, 0.0936262012, 0.158394992, -0.0704343989, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.67651403, 0.485114038))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.585665047, 0.483350217, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-2.07318115, -1.10149765, 0.990762711, 0.936944723, 0.325423121, 0.127415001, 0.311521977, -0.942941546, 0.117538534, 0.158394635, -0.0704345256, -0.98486048))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.485114038))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(3.68964601, 0.284894377, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-3.93379593, 0.833885193, 0.97751236, 0.807757795, -0.564388096, 0.170274884, -0.567836702, -0.822499335, -0.0325024389, 0.158394963, -0.0704342201, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.46041733))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.200000003, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-1.53672791, 1.18891907, 0.975282669, 0.780780971, -0.601626933, 0.168600783, -0.604393661, -0.79566586, -0.0403023846, 0.158396885, -0.0704338998, -0.984860182))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(0.926127851, 0.0855565146, 0.496580422))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.274662942, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-1.41918182, -1.06143951, 0.975307465, 0.799823642, 0.594020009, 0.08615347, 0.578959048, -0.801361144, 0.150422826, 0.158394217, -0.0704323947, -0.984860837))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.138478085, 0.496580422))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.253317922, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-1.39491653, -1.09104919, 0.990505219, 0.799823642, 0.594020009, 0.08615347, 0.578959048, -0.801361144, 0.150422826, 0.158394217, -0.0704323947, -0.984860837))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.154354557, 0.496580422))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.237157717, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.98400497, -4.65834808, 0.97530365, 0.541944027, 0.83997786, 0.0270890743, 0.825353324, -0.538030088, 0.171218053, 0.158394113, -0.0704325363, -0.984860778))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.386941314, 0.702734888))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(1.25244117, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-7.41493988, 1.11274576, 0.975286484, 0.983548343, 0.0989940166, 0.151105493, 0.0868522152, -0.992592216, 0.0849561989, 0.158396274, -0.0704346746, -0.984860301))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.238405704, 0.702734888))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.689254642, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.12310791, 0.369299412, 0.975299835, 0.983485222, 0.0997150019, 0.151042506, 0.0875668824, -0.992520034, 0.0850648731, 0.158394948, -0.0704337284, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.146039113, 0.702734888))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.341506928, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(5.58918381, -5.99747467, 0.975639343, -0.808163822, 0.563799143, -0.170299754, 0.567258239, 0.822903275, 0.0323817283, 0.158396989, -0.0704341903, -0.984860182))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.957367718, 0.686508358))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(1.81962168, 0.355486691, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-5.893013, 0.90151453, 0.975666046, 0.983717084, 0.0970459804, 0.15127039, 0.0849220082, -0.9927845, 0.0846598297, 0.158394784, -0.0704351366, -0.98486042))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.686508358))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(3.17940784, 0.322034985, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-6.39104462, 0.122011185, 0.978439331, 0.967768848, 0.208867997, 0.140704721, 0.195795536, -0.975404143, 0.101247005, 0.158391207, -0.0704343319, -0.984861076))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.651558757))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(4.93836689, 0.403167814, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-7.24019623, -0.105118752, 0.97844696, 0.967768848, 0.208867997, 0.140704721, 0.195795536, -0.975404143, 0.101247005, 0.158391207, -0.0704343319, -0.984861076))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.651558757))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.448602259, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-8.42969513, 0.914595604, 0.975681305, 0.983717084, 0.0970459804, 0.15127039, 0.0849220082, -0.9927845, 0.0846598297, 0.158394784, -0.0704351366, -0.98486042))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.962360442, 0.686508358))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.262121707, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-3.76428223, 0.469053268, 0.975311279, 0.975750566, 0.16377905, 0.145215094, 0.151071578, -0.983979464, 0.0946669132, 0.158393115, -0.0704334006, -0.984860837))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.121075168, 0.702734888))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.828803003, 0.684012294, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-2.99297905, -3.72123718, 0.975679398, 0.41831404, 0.908299506, 0.0023191215, 0.894385099, -0.41234833, 0.173333183, 0.158394724, -0.0704335123, -0.984860599))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.686508358))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.341506928, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-5.09734726, -4.65151978, 0.975683212, 0.567266881, 0.822897196, 0.0323816799, 0.808158159, -0.563807786, 0.170297772, 0.158394575, -0.0704347566, -0.98486048))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.957367718, 0.686508358))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(4.6140852, 0.403167814, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-7.05178833, -0.136793137, 0.978439331, 0.967768848, 0.208867997, 0.140704721, 0.195795536, -0.975404143, 0.101247005, 0.158391207, -0.0704343319, -0.984861076))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.651558757))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.388688922, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-1.29187584, -3.36907959, 0.975297928, 0.129877433, 0.990271986, -0.0499321222, 0.978796542, -0.120002069, 0.166003123, 0.158396259, -0.0704334378, -0.984860361))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.195967019, 0.702734888))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.35848251, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-1.37980461, -3.6240921, 0.975297928, 0.129877433, 0.990271986, -0.0499321222, 0.978796542, -0.120002069, 0.166003123, 0.158396259, -0.0704334378, -0.984860361))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.218434557, 0.702734888))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(1.29263294, 0.873988032, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.16244507, 0.637834072, 0.975681305, 0.983717084, 0.0970459804, 0.15127039, 0.0849220082, -0.9927845, 0.0846598297, 0.158394784, -0.0704351366, -0.98486042))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.686508358))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.341506928, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-6.35959244, -6.00856781, 0.975675583, 0.567266881, 0.822897196, 0.0323816799, 0.808158159, -0.563807786, 0.170297772, 0.158394575, -0.0704347566, -0.98486048))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.957367718, 0.686508358))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(1.86096573, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-2.24846649, 1.54257965, 0.975315094, 0.953437924, -0.248355001, 0.171102479, -0.256646633, -0.966104925, 0.0278172307, 0.158394381, -0.0704348683, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.177244052, 0.702734888))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(1.68831873, 0.818068683, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-2.39190674, 1.80307961, 0.975658417, 0.953437924, -0.248355001, 0.171102479, -0.256646633, -0.966104925, 0.0278172307, 0.158394381, -0.0704348683, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.686508358))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.591511309, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-2.40148163, 1.07713699, 0.975307465, 0.916328549, -0.361034989, 0.173192799, -0.367767662, -0.929888606, 0.00735405693, 0.158394948, -0.0704334453, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.125329256, 0.603079915))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.203526318, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.16732025, -2.63462067, 0.975311279, 0.857192576, 0.504842818, 0.101758391, 0.490032911, -0.860333264, 0.140337378, 0.158394426, -0.0704311877, -0.984860837))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.33206898, 0.603079915))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(1.07483196, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-5.22596741, 1.71432495, 0.975299835, 0.916060805, -0.361711085, 0.173198923, -0.368434012, -0.929625869, 0.00722825527, 0.158395633, -0.0704338774, -0.984860361))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.204597339, 0.603079915))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.211238876, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.10141754, -2.55089188, 0.975299835, 0.857192576, 0.504842818, 0.101758391, 0.490032911, -0.860333264, 0.140337378, 0.158394426, -0.0704311877, -0.984860837))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.0835528523, 0.603079915))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.739121258, 0.702058196, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-1.07832718, 1.86931229, 0.975631714, 0.733511806, -0.659313917, 0.165123463, -0.660962224, -0.748561502, -0.052769471, 0.158396706, -0.0704333335, -0.984860241))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.589154541))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(3.95976114, 0.345994473, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-5.0059433, 0.763832092, 0.97797966, 0.95138073, -0.255978942, 0.171317115, -0.26417011, -0.964112997, 0.0264637284, 0.158394933, -0.0704339445, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.559161127))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.293077767, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-5.30564117, -3.7974968, 0.975625992, 0.871970475, 0.477932125, 0.106058538, 0.463226855, -0.875568628, 0.13711533, 0.158393353, -0.0704313442, -0.984861016))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.821603239, 0.589154541))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.384985864, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-6.09538269, 1.54205513, 0.975639343, 0.915336847, -0.363533109, 0.173211187, -0.370229512, -0.928914845, 0.00688978424, 0.158393785, -0.0704343617, -0.984860659))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.825887859, 0.589154541))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.693274379, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-1.0522995, 1.64577866, 0.97530365, 0.733511806, -0.659313917, 0.165123463, -0.660962224, -0.748561502, -0.052769471, 0.158396706, -0.0704333335, -0.984860241))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.152109027, 0.603079915))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(2.72853518, 0.276367128, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.43891907, 0.985977173, 0.977996826, 0.95138073, -0.255978942, 0.171317115, -0.26417011, -0.964112997, 0.0264637284, 0.158394933, -0.0704339445, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.559161127))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(1.10932434, 0.750047624, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-2.43321991, 1.30454063, 0.975622177, 0.915336847, -0.363533109, 0.173211187, -0.370229512, -0.928914845, 0.00688978424, 0.158393785, -0.0704343617, -0.984860659))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.589154541))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.293077767, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(3.43746948, -4.99491119, 0.975624084, -0.46322152, 0.875570893, -0.137118205, 0.871973038, 0.477927417, 0.106059447, 0.158395112, -0.0704343617, -0.98486048))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.821603239, 0.589154541))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(1.56158078, 0.305075049, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-3.91834259, 1.53081131, 0.975627899, 0.915336847, -0.363533109, 0.173211187, -0.370229512, -0.928914845, 0.00688978424, 0.158393785, -0.0704343617, -0.984860659))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.589154541))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.293077767, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.22235107, -2.63276672, 0.975641251, 0.871970475, 0.477932125, 0.106058538, 0.463226855, -0.875568628, 0.13711533, 0.158393353, -0.0704313442, -0.984861016))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.821603239, 0.589154541))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.711270273, 0.587012351, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-2.65466309, -1.82859421, 0.975625992, 0.778281987, 0.622716069, 0.0806346312, 0.607608914, -0.779271126, 0.153453276, 0.158394083, -0.070435591, -0.984860599))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.589154541))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(4.32805729, 0.345994473, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-5.2126236, 0.791049957, 0.97797966, 0.95138073, -0.255978942, 0.171317115, -0.26417011, -0.964112997, 0.0264637284, 0.158394933, -0.0704339445, -0.984860539))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.559161127))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.22495015, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-2.14511108, 1.2347908, 0.975299835, 0.938221812, -0.300057828, 0.172352433, -0.307654411, -0.95131731, 0.0185542312, 0.158394471, -0.0704329461, -0.984860659))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.103905462, 0.603079915))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.333568811, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-1.60148621, -1.61552048, 0.975301743, 0.559441209, 0.82829988, 0.0307382643, 0.813594759, -0.555840254, 0.170602918, 0.158395961, -0.0704338253, -0.98486042))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.168176889, 0.603079915))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.307646036, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-1.67691803, -1.83437347, 0.975301743, 0.559441209, 0.82829988, 0.0307382643, 0.813594759, -0.555840254, 0.170602918, 0.158395961, -0.0704338253, -0.98486042))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.187458321, 0.603079915))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.336782306, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-2.19689178, -7.0763588, 0.975679398, 0.449534893, 0.893223107, 0.00841975678, 0.879108548, -0.444063395, 0.173136115, 0.158388063, -0.0704288334, -0.98486203))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.761616349, 0.589154541))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.483554214, 0.333232641, 0.251318902))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(1.37663269, 0.883522034, 0.967224121, -0.638958931, -0.767750859, -0.0478568636, -0.752756715, 0.636865556, -0.166612133, 0.158394992, -0.0704337209, -0.98486048))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.341453254, 0.333232641, 0.251318902))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.354263306, -3.787117, 0.967233658, -0.488823622, 0.86104399, -0.140195727, 0.857882738, 0.503629267, 0.101955138, 0.158394516, -0.0704334155, -0.984860599))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(2.0836575, 0.333232641, 0.251318902))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(2.75967407, -1.03858757, 0.96723938, -0.929733634, -0.346457034, -0.124752365, -0.33242473, 0.935417831, -0.120363601, 0.158396378, -0.070435293, -0.984860182))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.649142921, 0.236052051, 0.251318902))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(1.21902466, -0.0409164429, 0.967218399, -0.973333716, -0.178759977, -0.143758848, -0.165928215, 0.981368482, -0.0968699604, 0.15839687, -0.0704331398, -0.984860301))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.471516728, 0.234877661, 0.251318902))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.27822876, -0.853485107, 0.967250824, -0.630364001, 0.76051116, -0.155769765, 0.759969234, 0.645493507, 0.0760596395, 0.158392549, -0.0704349577, -0.984860837))
Part=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Really black","Part",Vector3.new(0.246144727, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-4.90726852, -4.56082153, 0.975297928, 0.541944027, 0.83997786, 0.0270890743, 0.825353324, -0.538030088, 0.171218053, 0.158394113, -0.0704325363, -0.984860778))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.0973593965, 0.702734888))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.88196522, 0.514088511, 0.251318902))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-2.70895958, -2.1431427, 0.967214584, 0.34296605, 0.939270973, -0.0120138666, 0.925896943, -0.335870683, 0.172933668, 0.158396453, -0.0704339668, -0.984860241))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(1.46827829, 0.952135324, 0.251318902))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-2.55020905, 0.0981483459, 0.967208862, 0.857882798, 0.50362891, 0.101956181, 0.488823354, -0.861044288, 0.140194699, 0.158394873, -0.070432052, -0.984860659))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.837632179, 0.333232641, 0.251318902))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.233604431, 1.92868805, 0.967222214, 0.752756357, -0.636865973, 0.166612104, -0.638958991, -0.76775068, -0.0478588976, 0.158396274, -0.070432201, -0.98486048))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.623012781, 0.333232641, 0.251318902))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.87634182, 1.67852783, 0.967235565, -0.00560861453, -0.997500658, 0.0704338476, -0.987359941, -0.00563267432, -0.158394292, 0.158395141, -0.0704319254, -0.984860659))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(4.53132343, 0.240000069, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(3.55789185, -1.3742981, 0.975597382, -0.766564727, 0.619903982, -0.16762352, 0.622331142, 0.781507432, 0.0441614315, 0.158374861, -0.0704647228, -0.984861553))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.67651403, 0.485114038))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.392539173, 0.333232641, 0.251318902))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-1.70851135, 0.724594116, 0.967193604, 0.857882798, 0.50362891, 0.101956181, 0.488823354, -0.861044288, 0.140194699, 0.158394873, -0.070432052, -0.984860659))
Part=CFuncs.Part.Create(m,Enum.Material.Glass,0,0.5,"Really black","Part",Vector3.new(0.313761592, 1.26770866, 1.29358757))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.971876144, -0.938801169, 0.994415283, -0.158395022, 0.0704339892, 0.984860539, 0.00561057869, 0.997500539, -0.0704356134, -0.987359941, -0.00563101377, -0.158394322))
CFuncs.Mesh.Create("SpecialMesh",Part,Enum.MeshType.Cylinder,"",Vector3.new(0, 0, 0),Vector3.new(1, 1, 1))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(7.26164198, 0.255189061, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-7.31764221, 0.649587631, 0.975751877, 0.889364362, 0.443439156, 0.111323781, 0.428885132, -0.893532991, 0.132877618, 0.158394605, -0.0704314858, -0.984860837))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 1, 0.807391346))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(6.94150734, 0.400000006, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(6.19526672, -1.05738401, 0.97567749, -0.983716667, -0.0970480368, -0.151272491, -0.0849231184, 0.992783904, -0.0846648067, 0.158397436, -0.0704396516, -0.984859765))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.957367718, 0.686508358))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(0.482433408, 0.200000003, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-1.00019741, -9.6156311, 0.975646973, -0.0838580653, 0.992889106, -0.084494181, 0.983808458, 0.0959719494, 0.151362404, 0.158395126, -0.0704331174, -0.984860599))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.887468517, 0.686508358))
Part=CFuncs.Part.Create(m,Enum.Material.SmoothPlastic,0,0,"Really black","Part",Vector3.new(5.6530838, 0.400000006, 0.200000003))
PartWeld=CFuncs.Weld.Create(m,Wing,Part,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(4.49669647, -1.63993073, 0.975580215, -0.91534394, 0.363514125, -0.173214182, 0.370208532, 0.928923249, -0.00687796436, 0.158402443, -0.0704210624, -0.984860241))
CFuncs.Mesh.Create("BlockMesh",Part,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.821603239, 0.589154541))
WingBox1=CFuncs.Part.Create(m,Enum.Material.Plastic,0,1,"Medium stone grey","WingBox1",Vector3.new(4.75000143, 0.859998941, 1))
WingBox1Weld=CFuncs.Weld.Create(m,Wing,WingBox1,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(3.52880096, -1.24272919, 1.0079422, -0.754450679, 0.642787635, -0.132771462, 0.633059144, 0.766044438, 0.11140985, 0.173321709, 1.05983202e-06, -0.984865308))
WingBox2=CFuncs.Part.Create(m,Enum.Material.Plastic,0,1,"Medium stone grey","WingBox2",Vector3.new(5.95000172, 0.859998941, 1))
WingBox2Weld=CFuncs.Weld.Create(m,Wing,WingBox2,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(4.70465088, -1.4642601, 1.00794601, -0.925470829, 0.342019886, -0.162868708, 0.336843431, 0.939692676, 0.0592801198, 0.173321515, 7.68129723e-07, -0.984865308))
WingBox3=CFuncs.Part.Create(m,Enum.Material.Plastic,0,1,"Medium stone grey","WingBox3",Vector3.new(7.54000759, 0.859998941, 1))
WingBox3Weld=CFuncs.Weld.Create(m,Wing,WingBox3,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(6.18742371, -0.404203415, 0.724849701, -0.969903171, -0.173648059, -0.170688078, -0.171019927, 0.984807849, -0.0300972071, 0.173321277, -3.13053391e-07, -0.984865427))
WingBox4=CFuncs.Part.Create(m,Enum.Material.Plastic,0,1,"Medium stone grey","WingBox4",Vector3.new(7.54000759, 1.04999876, 1))
WingBox4Weld=CFuncs.Weld.Create(m,Wing,WingBox4,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(7.18292236, 0.0431938171, 0.724849701, -0.852918625, -0.499999821, -0.150100783, -0.492432326, 0.866025567, -0.086661607, 0.173321888, -8.20131788e-07, -0.984865248))

Tattoo=CFuncs.Part.Create(m,Enum.Material.Plastic,0,1,"Medium stone grey","Tattoo",Vector3.new(0.610001087, 1, 0.890000403))
TattooWeld=CFuncs.Weld.Create(m,Character["Right Arm"],Tattoo,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.127849996, -0.4063797, 0.0113773346, 1, 0, 0, 0, 1, 0, 0, 0, 1))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.345474243, 0.369085073, 0.262099266, 0.000598000071, -0.993930101, -0.110012017, -0.999999881, -0.00062688929, 0.000228012228, -0.000295593578, 0.110011861, -0.99393034))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.644121528, 0.220589519, 0.328677952))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0644314513, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.257720947, -0.167019844, -0.368425012, 0, -0.999967635, -0.00804399699, 0, 0.00804399792, -0.999967635, 1, 0, 0))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.106284358, 0.220589191))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0693014264, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.234893799, 0.368422031, 0.179168701, 0, -0.309784949, -0.950806737, -1, 0, 0, 0, 0.950806737, -0.309784949))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.220589519, 0.213971585))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0644314513, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.164955139, -0.180831909, -0.368412971, 0, 0.334454924, 0.94241178, 0, -0.94241178, 0.334454924, 1, 0, 0))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.106284358, 0.220589191))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.347550929, 0.398170471, -0.139374733, -0.999999762, 0, -0.000665999833, 0, -1, 0, -0.000665999833, 0, 0.999999762))
CFuncs.Mesh.Create("SpecialMesh",tat,Enum.MeshType.Cylinder,"",Vector3.new(0, 0, 0),Vector3.new(0.882358313, 0.604415238, 0.580149591))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.218955994, -0.24905777, -0.368402004, 0, 0.595754027, 0.803166986, 0, -0.803166986, 0.595754027, 1, 0, 0))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.611055255, 0.229529798, 0.220589191))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0751109943, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.169723511, -0.17515564, 0.369192421, 0.000613000186, 0.402458102, -0.915438235, 0.000266000017, -0.915438473, -0.402458042, -0.999999762, 3.20027038e-06, -0.000668217719))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.179678485, 0.220589191))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.25983429, 0.368422985, 0.212726593, 0, -0.443343073, -0.896352112, -1, 0, 0, 0, 0.896352112, -0.443343073))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.644121528, 0.220589519, 0.328677952))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.202163279, 0.263536245))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.34772104, -0.348884583, 0.0236845016, 1, 0, 0, 0, -1, 0, 0, 0, -1))
CFuncs.Mesh.Create("SpecialMesh",tat,Enum.MeshType.Cylinder,"",Vector3.new(0, 0, 0),Vector3.new(0.882358313, 1, 1))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0644314513, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.113555908, -0.162574768, -0.369188726, -0.000631000206, -0.334430128, 0.942420363, 0.000220000045, -0.942420602, -0.334430069, 0.999999762, -3.69293139e-06, 0.000668242166))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.106284358, 0.220589191))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0693014264, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.326705933, 0.369078875, 0.215709686, 0.000634999829, -0.999417782, 0.0341119915, -0.999999881, -0.000627554022, 0.000228984747, -0.000207444304, -0.0341121294, -0.99941802))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.220589519, 0.213971585))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.286556244, 0.36839807, 0.232765198, 0, -0.519518971, -0.854458988, -1, 0, 0, 0, 0.854458988, -0.519518971))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.88676995, 0.220589519, 0.441178381))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.311698914, -0.263069153, -0.368406057, 0, -0.958490133, 0.28512603, 0, -0.28512603, -0.958490133, 1, 0, 0))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.611055255, 0.229529798, 0.220589191))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.367607117, 0.369083226, 0.289403915, 0.000567000068, -0.980618119, -0.195928022, -0.999999881, -0.000623347762, 0.000225930475, -0.000343682768, 0.195927858, -0.980618298))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.88676995, 0.220589519, 0.441178381))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0693014264, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.327262878, 0.368401051, 0.162896156, 0, 0.999418616, 0.0340939872, -1, 0, 0, 0, -0.0340939872, 0.999418616))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.220589519, 0.213971585))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.347545147, -0.169380188, -0.0945644379, -0.999999762, 0, -0.000665999833, 0, -1, 0, -0.000665999833, 0, 0.999999762))
CFuncs.Mesh.Create("SpecialMesh",tat,Enum.MeshType.Cylinder,"",Vector3.new(0, 0, 0),Vector3.new(0.882358313, 0.604415238, 0.580149591))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.239946365, 0.369184792, 0.204460144, 0.000572000048, 0.519502044, -0.854469121, -0.999999762, 1.87149126e-07, -0.000669307599, -0.00034754668, 0.85446924, 0.519501865))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.88676995, 0.220589519, 0.441178381))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0644314513, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.255828857, -0.219761848, -0.369092643, -0.000630000257, 0.999967337, -0.00806400273, 0.000228999779, 0.00806414895, 0.999967515, 0.999999881, 0.00062813313, -0.000234072708))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.106284358, 0.220589191))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.283638, 0.369182467, 0.164020538, -0.000550999946, 0.555142939, 0.831754863, -0.999999762, 2.51754983e-07, -0.000662622624, -0.000368059642, -0.831755042, 0.55514276))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.88676995, 0.220589519, 0.441178381))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.353614807, 0.368417025, 0.209962845, 0, 0.99392873, -0.110025972, -1, 0, 0, 0, 0.110025965, 0.99392873))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.644121528, 0.220589519, 0.328677952))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.355049014, -0.154151917, 0.0251083374, 1, 0, 0, 0, -1, 0, 0, 0, -1))
CFuncs.Mesh.Create("SpecialMesh",tat,Enum.MeshType.Cylinder,"",Vector3.new(0, 0, 0),Vector3.new(0.641915858, 0.604415238, 0.580149591))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.294418335, -0.312889099, -0.369074523, -0.000533999992, 0.958495021, 0.285109013, 0.000404000544, -0.285108835, 0.95849514, 0.999999881, 0.000627020549, -0.0002349844))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.611055255, 0.229529798, 0.220589191))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.347483039, -0.169380188, -0.0380096436, 1, 0, 0, 0, -1, 0, 0, 0, -1))
CFuncs.Mesh.Create("SpecialMesh",tat,Enum.MeshType.Cylinder,"",Vector3.new(0, 0, 0),Vector3.new(0.882358313, 0.604415238, 0.580149591))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.347493052, 0.398147583, -0.0826053619, 1, 0, 0, 0, -1, 0, 0, 0, -1))
CFuncs.Mesh.Create("SpecialMesh",tat,Enum.MeshType.Cylinder,"",Vector3.new(0, 0, 0),Vector3.new(0.882358313, 0.604415238, 0.580149591))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.414588928, 0.369088829, 0.243835449, -0.000558999716, 0.59172368, -0.806140661, -0.999999881, -0.000629997172, 0.000230996186, -0.000371180387, 0.806140602, 0.591723859))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.88676995, 0.220589519, 0.441178381))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.347535193, 0.438827515, -0.0946722031, -0.999999762, 0, -0.000665999833, 0, -1, 0, -0.000665999833, 0, 0.999999762))
CFuncs.Mesh.Create("SpecialMesh",tat,Enum.MeshType.Cylinder,"",Vector3.new(0, 0, 0),Vector3.new(0.882358313, 0.604415238, 0.580149591))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.347563624, -0.21006012, -0.156900406, -0.999999762, 0, -0.000665999833, 0, -1, 0, -0.000665999833, 0, 0.999999762))
CFuncs.Mesh.Create("SpecialMesh",tat,Enum.MeshType.Cylinder,"",Vector3.new(0, 0, 0),Vector3.new(0.882358313, 0.604415238, 0.580149591))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.329029083, 0.368404984, 0.194297791, 0, -0.555127263, 0.831765413, -1, 0, 0, 0, -0.831765413, -0.555127263))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.88676995, 0.220589519, 0.441178381))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0751109943, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.313224792, -0.190081596, 0.368412018, 0, 0.997878134, -0.0651090071, 0, -0.0651090071, -0.997878134, -1, 0, 0))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.179678485, 0.220589191))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0751109943, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.219703674, -0.197059631, 0.368417025, 0, -0.402481139, -0.915428281, 0, -0.915428281, 0.402481169, -1, 0, 0))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.179678485, 0.220589191))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.347500026, -0.21005249, -0.109327316, 1, 0, 0, 0, -1, 0, 0, 0, -1))
CFuncs.Mesh.Create("SpecialMesh",tat,Enum.MeshType.Cylinder,"",Vector3.new(0, 0, 0),Vector3.new(0.882358313, 0.604415238, 0.580149591))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0751109943, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.3074646, -0.242515564, 0.369079769, 0.000611000229, -0.997879326, -0.065090023, 0.00027400002, -0.0650898665, 0.997879446, -0.999999881, -0.000627539179, 0.000233649014))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.179678485, 0.220589191))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.175128937, -0.216575623, -0.369184375, -0.000537999789, -0.595736682, 0.803179622, 0.000395000359, -0.80317986, -0.595736563, 0.999999762, -3.24988355e-06, 0.000667426735))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.611055255, 0.229529798, 0.220589191))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.373477936, 0.368407011, 0.276912689, 0, -0.591739953, -0.80612886, -1, 0, 0, 0, 0.80612886, -0.591739953))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.88676995, 0.220589519, 0.441178381))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.347499013, 0.438827515, -0.0378713608, 1, 0, 0, 0, -1, 0, 0, 0, -1))
CFuncs.Mesh.Create("SpecialMesh",tat,Enum.MeshType.Cylinder,"",Vector3.new(0, 0, 0),Vector3.new(0.882358313, 0.604415238, 0.580149591))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0693014264, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.182982445, 0.369170189, 0.162239075, 0.000636000244, 0.309764117, -0.950813353, -0.999999762, -2.90834219e-08, -0.000668910507, -0.000207232108, 0.950813532, 0.309764028))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(1, 0.220589519, 0.213971585))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(0.380187988, 0.368409038, 0.238204956, 0, 0.980615497, -0.19594191, -1, 0, 0, 0, 0.19594191, 0.980615497))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.88676995, 0.220589519, 0.441178381))
tat=CFuncs.Part.Create(m,Enum.Material.Neon,0,0,"Bright green","tat",Vector3.new(0.0619654022, 0.0619653948, 0.0619653761))
tatWeld=CFuncs.Weld.Create(m,Tattoo,tat,CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),CFrame.new(-0.210956573, 0.369197965, 0.188514709, 0.000599000137, 0.443314105, -0.896366239, -0.999999762, 1.00843096e-07, -0.000668203749, -0.000296133716, 0.896366358, 0.443313986))
CFuncs.Mesh.Create("BlockMesh",tat,"","",Vector3.new(0, 0, 0),Vector3.new(0.644121528, 0.220589519, 0.328677952))

spawn(function()
while true do
for _,v in pairs(m:children()) do
if v:IsA("Part") and v.Name == "tat" then
v.Color = maincol2
end
end
swait()
end
end)


--Start neccessary functions here

function RArmTrace()
for _,v in next, Character:GetChildren() do
                if(v:IsA'Part') and v == RightArm and v ~= RootPart then
                        local trace = Instance.new("Part")
                        trace.Parent = Character
                        trace.Size = v.Size
                        trace.Material = "Neon"
                        trace.Color = maincol
						trace.Transparency = .3
                        trace.Anchored = true
                        trace.CanCollide = false
                        trace.CFrame = v.CFrame
                        Tween(trace,{Transparency=1},.5)
							game:GetService("Debris"):AddItem(trace, 1)
                        	if v.Name == "Head" then
                            local mehs = Instance.new("CylinderMesh",trace)
                            mehs.Scale = Vector3.new(1.25,1.25,1.25)
                        end
                end
            end
			end


function punch1()
	Attack = true
	CFuncs.Sound.Create("160772554", Torso, 1, .5)
	for i = 0, 5, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, 1.25783896, 0.0750579834, 1, 0, 0, 0, 1, 0, 0, 0, 1) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0 + .2 * math.cos(Sine/30), 0), 
         CFrame.new(0, 1.5722059, -0.165335715, 1, 0, 0, 0, 0.996194661, 0.087155968, 0, -0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.770152092, 1.15917587, -0.772684395, 0.669632077, 0.727706194, -0.14844726, 0.385775059, -0.511604249, -0.767749131, -0.634642065, 0.456842214, -0.62331754) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.29209483, 1.91917002, -0.0983848572, -0.225760028, -0.171030968, 0.959052086, 0.12644501, -0.981284738, -0.145230755, 0.965942144, 0.0884800404, 0.243160874) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.38367569, -0.476289868, 1, 0, -0, 0, 0.996194661, -0.087155968, 0, 0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.97375119, -0.383697003, 1, 0, -0, 0, 0.996194661, -0.087155968, 0, 0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
		Effects.Sphere2.Create(BrickColor.new(maincol), workspace, LeftArm.CFrame * CFrame.new(0,-1,0), 1, 1, 1, 1, 1, 1, .08)
		WingWeld.C0 = clerp(WingWeld.C0, CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0 - 30 * math.cos(Sine/30)/2)), 0.1)
	end
			local refpart = CFuncs.Part.Create(EffectModel, "SmoothPlastic", 0, 1, "Really black", "Effect", Vector3.new(2,2,2))
			refpart.Anchored = true
			refpart.CFrame = RootPart.CFrame * CFrame.new(0,-3,-2)
			CFuncs.Sound.Create("161006163", refpart, 1, .5) 
	local x = -2
	for i = 0, 5, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(-0.16791907, 1.25783801, -0.158113495, 0.500002861, 0.29619804, -0.813796043, 0, 0.939692497, 0.342020661, 0.866023839, -0.171011299, 0.469848901) * CFrame.new(0, 0 + .2 * math.cos(Sine/30), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-6.46886292e-06, 1.62946367, -0.0650552511, 1.00000012, 4.02331352e-06, -6.97374344e-06, -2.74181366e-06, 0.98480773, 0.173648745, 7.53998756e-06, -0.173648715, 0.98480773) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.612076044, 1.2946707, -0.631058097, 0.6696347, 0.727704465, -0.148444876, 0.579569697, -0.637001276, -0.508260369, -0.464422941, 0.254314631, -0.848313451) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.94840646, 0.622272074, -0.543509424, 0.0544967018, 0.675845683, 0.735025764, 0.990212917, -0.131301612, 0.047313042, 0.12848635, 0.725253463, -0.676386535) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.499989152, -1.13731849, -0.920836091, 0.984807372, -6.66826963e-07, -0.173651665, -0.0733877793, 0.906307876, -0.416197658, 0.157382131, 0.422618359, 0.892538369) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.636995614, -1.71154809, -1.03457654, 0.996194661, 0.0871571898, -5.48362732e-06, -0.0868259892, 0.992403746, -0.0871572122, -0.00759088993, 0.0868260115, 0.99619472) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
		Effects.Sphere2.Create(BrickColor.new(maincol), workspace, refpart.CFrame, 1, 3, 1, 5, 10, 5, .04)
		WingWeld.C0 = clerp(WingWeld.C0, CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0 - 30 * math.cos(Sine/30)/2)), 0.1)
		refpart.CFrame = refpart.CFrame * CFrame.new(0,0,x)
		MagnitudeDamage(refpart, 10, 0, 0, 0, "Normal", " ", 1)
		x = x - .01
	end
	local x = -2
	refpart:Destroy()
		Torso.Velocity=RootPart.CFrame.lookVector*0
	Attack = false
end
	
	
	
function explodeatmouse()
	Attack = true
		for i = 0, 1, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, 1.25783896, 0.0750579834, 1, 0, 0, 0, 1, 0, 0, 0, 1) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.5722059, -0.165335715, 1, 0, 0, 0, 0.996194661, 0.087155968, 0, -0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.770152092, 1.15917587, -0.772684395, 0.669632077, 0.727706194, -0.14844726, 0.385775059, -0.511604249, -0.767749131, -0.634642065, 0.456842214, -0.62331754) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.29209483, 1.91917002, -0.0983848572, -0.225760028, -0.171030968, 0.959052086, 0.12644501, -0.981284738, -0.145230755, 0.965942144, 0.0884800404, 0.243160874) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.38367569, -0.476289868, 1, 0, -0, 0, 0.996194661, -0.087155968, 0, 0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.97375119, -0.383697003, 1, 0, -0, 0, 0.996194661, -0.087155968, 0, 0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .2, false)
		end
		local egg = Mouse.Hit
local shur = Instance.new("Part",Character)
		local gahd = Instance.new("Sound",shur)
shur.Transparency = 1
shur.Material = "Neon"
shur.BrickColor = BrickColor.new("Royal purple")
shur.Anchored = true
shur.CFrame = Mouse.Hit
shur.Rotation = Vector3.new(0,math.random(-500,500),0)
shur.Size = Vector3.new(1,0.2,1)
shur.CanCollide = false
local dec = Instance.new("Decal",shur)
dec.Texture = "rbxassetid://1208118228"
dec.Face = "Top"
dec.Color3 = Color3.new(0,0,0)
table.insert(Effects, {dec,"Disappear",.01})
local value1 = 1*2.25
local x = 500
CFuncs.Sound.Create("331888777", shur, 10, .9)
	for i = 0, 5, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(-0.16791907, 1.25783801, -0.158113495, 0.500002861, 0.29619804, -0.813796043, 0, 0.939692497, 0.342020661, 0.866023839, -0.171011299, 0.469848901) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-6.46886292e-06, 1.62946367, -0.0650552511, 1.00000012, 4.02331352e-06, -6.97374344e-06, -2.74181366e-06, 0.98480773, 0.173648745, 7.53998756e-06, -0.173648715, 0.98480773) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.612076044, 1.2946707, -0.631058097, 0.6696347, 0.727704465, -0.148444876, 0.579569697, -0.637001276, -0.508260369, -0.464422941, 0.254314631, -0.848313451) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.94840646, 0.622272074, -0.543509424, 0.0544967018, 0.675845683, 0.735025764, 0.990212917, -0.131301612, 0.047313042, 0.12848635, 0.725253463, -0.676386535) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.499989152, -1.13731849, -0.920836091, 0.984807372, -6.66826963e-07, -0.173651665, -0.0733877793, 0.906307876, -0.416197658, 0.157382131, 0.422618359, 0.892538369) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.636995614, -1.71154809, -1.03457654, 0.996194661, 0.0871571898, -5.48362732e-06, -0.0868259892, 0.992403746, -0.0871572122, -0.00759088993, 0.0868260115, 0.99619472) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
		shur.CFrame = Mouse.Hit
		shur.Rotation = Vector3.new(0,x,0)
		x = x - 5
	shur.Size = shur.Size + Vector3.new(value1,0,value1)
	value1 = value1 - 0.015*2.25
	end
	CFuncs.Sound.Create("919941001", Character, 1, 1)
		Effects.Sphere2.Create(BrickColor.new("Smoky grey"), workspace, shur.CFrame, 4, 8, 4, 20, 40, 20, .01)
	Effects.Sphere2.Create(BrickColor.new(maincol), workspace, shur.CFrame, 5, 10, 5, 25, 50, 25, .01)
	Effects.Wave.Create(BrickColor.new("Smoky grey"), shur.CFrame, 4, .001, 4, 4, .01, 4, .01)
	Effects.Wave.Create(BrickColor.new(maincol), shur.CFrame, 4, .001, 4, 5, .01, 5, .01)
	for i = 0, 10 do
		local refpart = CFuncs.Part.Create(EffectModel, "SmoothPlastic", 0, 0, "Really black", "Effect", Vector3.new(5,5,5))
		refpart.Anchored = false
		refpart.CFrame = shur.CFrame * CFrame.new(math.random(-5,5), math.random(0,0),math.random(-5,5))
		refpart.CanCollide = true
		refpart.Velocity = Vector3.new(math.random(-60,60),math.random(80,150),math.random(-60,60))
		game:GetService("Debris"):AddItem(refpart, 2)
							table.insert(Effects, {refpart,"Disappear",.01})
							local hit, pos = RayCast(shur.Position, (CFrame.new(shur.Position, shur.Position - Vector3.new(0, 1, 0))).lookVector, 10, shur)
							if hit ~= nil then
							refpart.Material = hit.Material
							refpart.BrickColor = BrickColor.new(hit.Color)
							CFuncs.Sound.Create("172019967", refpart, 1, 1)
							end	
	end
	dec:Destroy()
	shur:Destroy()
	MagnitudeDamage(shur, 40, 0, 0, 80, "Normal", " ", 1)
		Attack = false
end

local deathrain = false

function armagedd()
	Attack = true
	deathrain = true
		for i = 0, 1, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, 1.25783896, 0.0750579834, 1, 0, 0, 0, 1, 0, 0, 0, 1) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.5722059, -0.165335715, 1, 0, 0, 0, 0.996194661, 0.087155968, 0, -0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.770152092, 1.15917587, -0.772684395, 0.669632077, 0.727706194, -0.14844726, 0.385775059, -0.511604249, -0.767749131, -0.634642065, 0.456842214, -0.62331754) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.29209483, 1.91917002, -0.0983848572, -0.225760028, -0.171030968, 0.959052086, 0.12644501, -0.981284738, -0.145230755, 0.965942144, 0.0884800404, 0.243160874) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.38367569, -0.476289868, 1, 0, -0, 0, 0.996194661, -0.087155968, 0, 0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.97375119, -0.383697003, 1, 0, -0, 0, 0.996194661, -0.087155968, 0, 0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .2, false)
		end
local shur = Instance.new("Part",Camera)
shur.CFrame = Mouse.Hit
shur.Anchored = true
shur.CanCollide = false
shur.Transparency = 1
shur.Rotation = Vector3.new(0,500,0)
CFuncs.Sound.Create("331888777", shur, 10, .9)
	for i = 0, 2, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, 1.50806487, -0.0493182242, 1, 0, 0, 0, 0.965925872, 0.258818984, 0, -0.258818984, 0.965925872) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.57220507, -0.165325716, 1, 0, 0, 0, 0.99619478, -0.0871558785, 0, 0.0871558785, 0.99619478) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.770143628, 1.15917659, -0.772669554, 0.669632196, 0.727706075, -0.148447335, 0.385774463, -0.511604011, -0.767749667, -0.634642303, 0.456842661, -0.623317003) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.15002179, 0.770601869, -1.3447417, 0.150704995, -0.239807919, 0.959051669, 0.988570929, 0.0404406041, -0.145231575, -0.00395695865, 0.969977796, 0.243161768) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.38367522, -0.476285875, 1, 0, 0, 0, 0.99619478, -0.0871558785, 0, 0.0871558785, 0.99619478) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.97375286, -0.38368547, 1, 0, 0, 0, 0.99619478, -0.0871558785, 0, 0.0871558785, 0.99619478) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .2, false)
	end
		Attack = false
	for i = 1, 20 do
	local met = Instance.new("Part",workspace)
	met.CFrame = shur.CFrame * CFrame.new(math.random(-50,50),300,math.random(-50,50))
	met.Anchored = false
	met.CanCollide = false
	met.Transparency = 0
	met.Size = Vector3.new(.1,.1,.1)
	met.Material = "Neon"
	met.BrickColor = BrickColor.new(maincol)
	        local mbewm2 = Instance.new("SpecialMesh", met)
        mbewm2.MeshType = "Sphere"
        mbewm2.Scale = Vector3.new(100,100,100)
	local con = met.Touched:connect(function(hit)
		if hit ~= met and hit.Name ~= "Effect" and hit.Name ~= "what" then
	MagnitudeDamage(met, 30, 0, 0, 20, "Normal", " ", 1)
	CFuncs.Sound.Create("239000203", workspace, .5, 1)
	Effects.Sphere2.Create(BrickColor.new("Smoky grey"), EffectModel, met.CFrame, 1, 3, 1, 5, 10, 5, .01)
	Effects.Sphere2.Create(BrickColor.new(maincol), EffectModel, met.CFrame, 2, 4, 2, 6, 11, 6, .01)
	
	for i = 0, 5 do
		local frag = CFuncs.Part.Create(EffectModel, "Neon", 0, 0, "Really black", "Effect", Vector3.new(.1,.1,.1))
		frag.Anchored = false
		frag.CFrame = met.CFrame * CFrame.new(math.random(-5,5), 10,math.random(-5,5))
		frag.CanCollide = false
		frag.Velocity = Vector3.new(math.random(-100,100),math.random(80,150),math.random(-100,100))
			local flame = Instance.new("Fire",frag)
	flame.SecondaryColor = Color3.new(0,0,0)
	flame.Color = Color3.new(0,0,0)
	flame.Heat = 15
		local mbewm2 = Instance.new("SpecialMesh", frag)
        mbewm2.MeshType = "Sphere"
        mbewm2.Scale = Vector3.new(50,50,50)
		local con = frag.Touched:connect(function(hit)
					if hit ~= met and hit.Name ~= "Effect" and hit.Name ~= frag then
	MagnitudeDamage(frag, 25, 0, 0, 20, "Normal", " ", 1)
	CFuncs.Sound.Create("206049428", workspace, .5, 1)
	Effects.Sphere2.Create(BrickColor.new("Smoky grey"), EffectModel, frag.CFrame, .5, 2, .5, 3, 5, 3, .03)
	Effects.Sphere2.Create(BrickColor.new(maincol), EffectModel, frag.CFrame, .6, 3, .6, 4, 6, 4, .03)
	frag:Destroy()
			end
	end)
	met:Destroy()end end end)
	Effects.Sphere2.Create(BrickColor.new("Smoky grey"), EffectModel, shur.CFrame, .5, 2, .5, .5, 10, .5, .03)
	wait(.5)
	end
	deathrain = false
	shur:Destroy()
end


function obliterate()
	Attack = true
	Humanoid.WalkSpeed = 0
	Humanoid.JumpPower = 0
	Humanoid.AutoRotate = false
	local refpart = CFuncs.Part.Create(EffectModel, "SmoothPlastic", 0, 1, "Really black", "Effect", Vector3.new())
	refpart.Anchored = true
	refpart.CFrame = RootPart.CFrame * CFrame.new(0,80,0)
			local smonk1 = Instance.new("ParticleEmitter",refpart)
			smonk1.LightEmission = .5
			smonk1.Size = NumberSequence.new(0.2)
			smonk1.Texture = "rbxassetid://382425306"
			aaa = NumberSequence.new({NumberSequenceKeypoint.new(0, 0),NumberSequenceKeypoint.new(.2, 5),NumberSequenceKeypoint.new(.4, 10),NumberSequenceKeypoint.new(.564, 20),NumberSequenceKeypoint.new(.784, 50),NumberSequenceKeypoint.new(1, 100)})
			bbb = NumberSequence.new({NumberSequenceKeypoint.new(0, .3), NumberSequenceKeypoint.new(.7, .5), NumberSequenceKeypoint.new(1, 1)})
			smonk1.Transparency = bbb
			smonk1.Size = aaa
			smonk1.ZOffset = .5
			smonk1.Acceleration = Vector3.new(0, 0, 0)
			smonk1.LockedToPart = false
			smonk1.EmissionDirection = "Top"
			smonk1.Lifetime = NumberRange.new(3, 3)
			smonk1.Rate = 5
			smonk1.Rotation = NumberRange.new(0, 50)
			smonk1.RotSpeed = NumberRange.new(50, 50)
			smonk1.Speed = NumberRange.new(0)
			smonk1.VelocitySpread = 0
			smonk1.Enabled=true
		local startColor = maincol
local endColor = maincol
local sequence2 = ColorSequence.new(startColor, endColor)
smonk1.Color = sequence2
			local smonk2 = Instance.new("ParticleEmitter",refpart)
			smonk2.LightEmission = .5
			smonk2.Size = NumberSequence.new(0.2)
			smonk2.Texture = "rbxassetid://95648201"
			aaa = NumberSequence.new({NumberSequenceKeypoint.new(0, 0),NumberSequenceKeypoint.new(.2, 5),NumberSequenceKeypoint.new(.4, 10),NumberSequenceKeypoint.new(.564, 20),NumberSequenceKeypoint.new(.784, 50),NumberSequenceKeypoint.new(1, 100)})
			bbb = NumberSequence.new({NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1)})
			smonk2.Transparency = bbb
			smonk2.Size = aaa
			smonk2.ZOffset = .5
			smonk2.Acceleration = Vector3.new(0, 0, 0)
			smonk2.LockedToPart = false
			smonk2.EmissionDirection = "Top"
			smonk2.Lifetime = NumberRange.new(3, 3)
			smonk2.Rate = 5
			smonk2.Rotation = NumberRange.new(0, 50)
			smonk2.RotSpeed = NumberRange.new(50, 50)
			smonk2.Speed = NumberRange.new(0)
			smonk2.VelocitySpread = 0
			smonk2.Enabled=true
		local startColor = maincol
local startColor = maincol
local endColor = maincol
local sequence3 = ColorSequence.new(startColor, endColor)
smonk2.Color = sequence3
CFuncs.Sound.Create("376020049", refpart, 1, 1)
local void = Instance.new("Sound", refpart)
void.Looped = true
void.SoundId = "rbxassetid://565538601"
void:Play()

		for i = 0, 8, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, 1.25783896, 0.0750579834, 1, 0, 0, 0, 1, 0, 0, 0, 1) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.5722059, -0.165335715, 1, 0, 0, 0, 0.996194661, 0.087155968, 0, -0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.770152092, 1.15917587, -0.772684395, 0.669632077, 0.727706194, -0.14844726, 0.385775059, -0.511604249, -0.767749131, -0.634642065, 0.456842214, -0.62331754) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.29209483, 1.91917002, -0.0983848572, -0.225760028, -0.171030968, 0.959052086, 0.12644501, -0.981284738, -0.145230755, 0.965942144, 0.0884800404, 0.243160874) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.38367569, -0.476289868, 1, 0, -0, 0, 0.996194661, -0.087155968, 0, 0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.97375119, -0.383697003, 1, 0, -0, 0, 0.996194661, -0.087155968, 0, 0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
		Effects.Sphere2.Create(BrickColor.new(maincol), EffectModel, refpart.CFrame, 2, 2, 2, 2, 2, 2, .01)
		end
	Humanoid.WalkSpeed = 8
	Humanoid.JumpPower = 0
	Humanoid.AutoRotate = true
	Attack = false
		for i = 0, 100, 0.1 do
		swait()
				local startColor = maincol
local endColor = maincol
local sequence2 = ColorSequence.new(startColor, endColor)
smonk1.Color = sequence2
		shoot(Mouse,8,refpart,0,7)
		Effects.Sphere2.Create(BrickColor.new(maincol), EffectModel, refpart.CFrame, 2, 2, 2, 2, 2, 2, .01)
		end
		refpart:Destroy()
end



function bring()
	Attack = true
	Humanoid.JumpPower = 1
	Humanoid.AutoRotate = false
	Humanoid.WalkSpeed = 0
	CFuncs.Sound.Create("299058146", RootPart, 5, 1)
	for i = 0, 9, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(-0, -0.0774844885, -0.0541736633, 1, 0, 0, 0, 0.939692736, 0.342019886, 0, -0.342019916, 0.939692736) * CFrame.new(0, 0 + .2 * math.cos(Sine/30), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.6414876, -0.193552464, 1, 0, 0, 0, 0.939692438, 0.342020929, 0, -0.342020959, 0.939692438) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(1.62857544, -0.00206083059, -0.25739941, -0.00411200058, -0.0845740512, -0.996408761, -0.682358861, 0.728630245, -0.059029337, 0.731005847, 0.679665625, -0.0607059747) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.63951504, -0.025425151, -0.475234687, 0.0133920014, 0.142243981, 0.989741087, 0.646753192, 0.753661752, -0.11706613, -0.762581944, 0.641685903, -0.0819036961) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.49319136, -0.532124996, 1, 0, 0, 0, 0.99619472, 0.0871556401, 0, -0.0871556699, 0.99619472) * CFrame.new(0, 0 - .2 * math.cos(Sine/30), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -2.11923552, 0.210575998, 1, 0, 0, 0, 0.866024256, 0.500002146, 0, -0.500002146, 0.866024256) * CFrame.new(0, 0 - .2 * math.cos(Sine/30), 0) * CFrame.Angles(0, 0, 0), 
		}, .03, false)
		WingWeld.C0 = clerp(WingWeld.C0, CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(30)), 0.1)
	end
	Effects.Wave.Create(BrickColor.new("Smoky grey"), Torso.CFrame, 3, .001, 3, 3, .01, 3, .05)
	CFuncs.Sound.Create("592877506", RootPart, 5, 1)
	Humanoid.Jump = true
		for i = 0, 3, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, 1.63284409, -0.235706627, 1, 0, 0, 0, 0.76604414, 0.642788053, 0, -0.642788053, 0.76604414) * CFrame.new(0, 0 + .2 * math.cos(Sine/30), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.41601598, 0.037264809, 1, 0, 0, 0, 0.984807849, -0.173648536, 0, 0.173648536, 0.984807849) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(1.61149979, -0.0398547351, 0.059716776, 0.0984320119, -0.24887298, -0.963521421, 0.144319385, 0.961557448, -0.233622223, 0.984623313, -0.116058946, 0.130565256) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.63550019, -0.0676878393, 0.268953949, -0.0868250281, 0.150387004, 0.984807193, -0.415071696, 0.893190742, -0.172991112, -0.905636191, -0.423785478, -0.0151299238) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.49319172, -0.532124639, 1, 0, 0, 0, 0.996194839, 0.0871559381, 0, -0.0871559381, 0.996194839) * CFrame.new(0, 0 - 1 * math.cos(Sine/30), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -2.11924171, 0.210577607, 1, 0, 0, 0, 0.866025209, 0.500000656, 0, -0.500000596, 0.86602515) * CFrame.new(0, 0 + 1 * math.cos(Sine/30), 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
		Trace()
		WingWeld.C0 = clerp(WingWeld.C0, CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(-50)), 0.1)
		Torso.Velocity = Torso.CFrame.upVector*200
		end
		Humanoid.AutoRotate = true
			for i = 0, 2, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, 1.78658676, 0.0318150818, 1, 0, 0, 0, 0.965925872, 0.258818984, 0, -0.258818984, 0.965925872) * CFrame.new(0, 0 + .2 * math.cos(Sine/20), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.56547379, -3.30805779e-06, 1, 0, 0, 0, 0.99619478, 0.0871555507, 0, -0.0871555805, 0.99619478) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(1.57282138, -0.0133092105, -0.178220585, 0.159491047, -0.214918017, -0.963521123, -0.109468222, 0.966145396, -0.233623564, 0.981111348, 0.142735809, 0.130564839) * CFrame.new(0, .2 - .1 * math.cos(Sine/20), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.62371719, 0.0323515683, -0.108368635, 0.0301549919, 0.171015948, 0.984806716, 0.25616771, 0.951026499, -0.172993779, -0.966161847, 0.257492334, -0.0151305683) * CFrame.new(0, .2 - .1 * math.cos(Sine/20), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.94789934, -0.437906563, 1, 0, 0, 0, 0.99619478, 0.0871555507, 0, -0.0871555805, 0.99619478) * CFrame.new(0, 0 + .1 * math.cos(Sine/20), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.26627839, -0.317767948, 1, 0, 0, 0, 1.00000012, 3.14414501e-06, 0, -3.14414501e-06, 1.00000012) * CFrame.new(0, 0 - .1 * math.cos(Sine/20), 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
		WingWeld.C0 = clerp(WingWeld.C0, CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(-10 - 40 * math.cos(Sine/20)/2)), 0.1)
			end

				for i = 0, 2, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(-1.5999575e-08, 1.44234729, 0.183013797, 1, -3.69464352e-08, -7.92319526e-08, 0, 0.906307876, -0.422617942, 8.74227766e-08, 0.422617942, 0.906307876) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.63241386, -0.347857296, 1, 0, 0, 0, 0.866025388, 0.499999881, -0, -0.499999881, 0.866025388) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(1.98610222, 0.463692427, -0.267273933, 0.08378198, -0.979906499, 0.181008324, 0.975164294, 0.0432518646, -0.217218786, 0.205025166, 0.194711864, 0.959193349) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.95457983, 0.565388799, -0.316161066, 0.00718499674, 0.98882252, -0.148924112, -0.995118618, -0.00758796558, -0.0983929336, -0.098423183, 0.1489041, 0.983941317) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.40934074, -0.485016495, 1, 0, -0, 0, 0.99619472, 0.0871556699, -0, -0.0871556401, 0.99619472) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -2.02685142, -0.436531007, 1, 0, -0, 0, 0.999999881, 0, -0, 0, 0.999999881) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
				end
	Effects.Wave.Create(BrickColor.new("Smoky grey"), Torso.CFrame, 3, .001, 3, 3, .01, 3, .02)
	Effects.Wave.Create(BrickColor.new(maincol), Torso.CFrame, 3, .001, 3, 4, .01, 4, .02)
	CFuncs.Sound.Create("157498544", Character, 1, 1)
	Humanoid.AutoRotate = false
	local hit = nil
	while hit == nil do
		swait()
		local hit, pos = RayCast(RootPart.Position, (CFrame.new(RootPart.Position, RootPart.Position - Vector3.new(0, 1, 0))).lookVector, 10, Character)
		PlayAnimationFromTable({
         CFrame.new(-1.5999575e-08, 1.44234729, 0.183013797, 1, -3.69464352e-08, -7.92319526e-08, 0, 0.906307876, -0.422617942, 8.74227766e-08, 0.422617942, 0.906307876) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.63241386, -0.347857296, 1, 0, 0, 0, 0.866025388, 0.499999881, -0, -0.499999881, 0.866025388) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(1.98610222, 0.463692427, -0.267273933, 0.08378198, -0.979906499, 0.181008324, 0.975164294, 0.0432518646, -0.217218786, 0.205025166, 0.194711864, 0.959193349) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.95457983, 0.565388799, -0.316161066, 0.00718499674, 0.98882252, -0.148924112, -0.995118618, -0.00758796558, -0.0983929336, -0.098423183, 0.1489041, 0.983941317) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.40934074, -0.485016495, 1, 0, -0, 0, 0.99619472, 0.0871556699, -0, -0.0871556401, 0.99619472) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -2.02685142, -0.436531007, 1, 0, -0, 0, 0.999999881, 0, -0, 0, 0.999999881) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
		Trace()
		Torso.Velocity = Torso.CFrame.upVector*-200
		if hit ~= nil then
			break
		end
	end
	Humanoid.JumpPower = 0
			for i = 0, .1, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(-0, -1.05290782, -0.0541787446, 1, 0, 0, 0, 0.64278698, 0.766044974, 0, -0.766044974, 0.64278698) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.5934242, -0.176076397, 1, 0, 0, 0, 0.965925694, 0.258819431, 0, -0.258819431, 0.965925694) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(1.50508034, -0.00486692786, -1.10916901, 0.996568024, -0.019198034, 0.0805210844, 0.0782727599, 0.5350824, -0.841166019, -0.0269366801, 0.844581723, 0.534748673) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.81366992, 0.249244243, -0.337208867, 0.0133940047, 0.47217676, 0.881402194, 0.941395521, 0.291164994, -0.170286, -0.337038577, 0.832028806, -0.440605283) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.6015507, -0.464419425, 1, 0, 0, 0, 0.766044974, 0.64278698, 0, -0.64278698, 0.766044974) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -0.554469764, -0.85574472, 1, 0, 0, 0, 0.64278698, -0.766044974, 0, 0.766044974, 0.64278698) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
			end
				for i = 0, 10 do
		local refpart = CFuncs.Part.Create(EffectModel, "SmoothPlastic", 0, 0, "Really black", "Effect", Vector3.new(math.random(1,3),math.random(1,3),math.random(1,3)))
		refpart.Anchored = false
		refpart.CFrame = RootPart.CFrame * CFrame.new(math.random(-5,5), 10,math.random(-5,5))
		refpart.CanCollide = true
		refpart.Velocity = Vector3.new(math.random(-60,60),math.random(80,150),math.random(-60,60))
		game:GetService("Debris"):AddItem(refpart, 2)
							table.insert(Effects, {refpart,"Disappear",.01})
							local hit, pos = RayCast(RootPart.Position, (CFrame.new(RootPart.Position, RootPart.Position - Vector3.new(0, 1, 0))).lookVector, 10, shur)
							if hit ~= nil then
							refpart.Material = hit.Material
							refpart.BrickColor = BrickColor.new(hit.Color)
							end	
			end
			MagnitudeDamage(Torso, 50, 0, 0, 0, "Normal", " ", 1)
					Effects.Sphere2.Create(BrickColor.new("Smoky grey"), workspace, RootPart.CFrame, 4, 8, 4, 20, 40, 20, .03)
	Effects.Sphere2.Create(BrickColor.new(maincol), workspace, RootPart.CFrame, 5, 10, 5, 25, 50, 25, .03)
	Effects.Wave.Create(BrickColor.new("Smoky grey"), RootPart.CFrame*CFrame.new(0,-2,0), 4, .001, 4, 4, .01, 4, .03)
	Effects.Wave.Create(BrickColor.new(maincol), RootPart.CFrame*CFrame.new(0,-2,0), 4, .001, 4, 5, .01, 5, .03)
			CFuncs.Sound.Create("638744427", Character, 5, 1)
			CFuncs.Sound.Create("765590102", RootPart, 5, 1)
	Torso.Velocity = Torso.CFrame.upVector*0
		for i = 0, 5, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(-0, -1.05290782, -0.0541787446, 1, 0, 0, 0, 0.64278698, 0.766044974, 0, -0.766044974, 0.64278698) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.5934242, -0.176076397, 1, 0, 0, 0, 0.965925694, 0.258819431, 0, -0.258819431, 0.965925694) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(1.50508034, -0.00486692786, -1.10916901, 0.996568024, -0.019198034, 0.0805210844, 0.0782727599, 0.5350824, -0.841166019, -0.0269366801, 0.844581723, 0.534748673) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.81366992, 0.249244243, -0.337208867, 0.0133940047, 0.47217676, 0.881402194, 0.941395521, 0.291164994, -0.170286, -0.337038577, 0.832028806, -0.440605283) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.6015507, -0.464419425, 1, 0, 0, 0, 0.766044974, 0.64278698, 0, -0.64278698, 0.766044974) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -0.554469764, -0.85574472, 1, 0, 0, 0, 0.64278698, -0.766044974, 0, 0.766044974, 0.64278698) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
		end
		Humanoid.WalkSpeed = 8
		Humanoid.AutoRotate = true
	Attack = false
end




spawn(function()
	while true do
		wait(.2)				
	Effects.Sphere2.Create(BrickColor.new(maincol), EffectModel, RootPart.CFrame * CFrame.new(math.random(-10,10),-3,math.random(-10,10)), .1, 3, .1, .1, 3, .1, .02)
	end
end)

function detonate()
	Attack = true
	Humanoid.JumpPower = 50
	Humanoid.WalkSpeed = 0
	Humanoid.AutoRotate = false
	Humanoid.Jump = true
	for i = 0, 90, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, 1.42191756, -0.0488209724, 1, 0, 0, 0, 0.965925872, 0.258818984, 0, -0.258818984, 0.965925872) * CFrame.new(0, 0 + .2 * math.cos(Sine/30), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.57220244, -0.165338278, 1, 0, 0, 0, 0.906307578, 0.422618866, 0, -0.422618866, 0.906307578) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(1.07328367, 0.536740482, -0.867595553, 0.405946076, 0.905454516, 0.123935826, 0.327782422, -0.0176637098, -0.944588244, -0.853092313, 0.424075872, -0.303962588) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.15903234, 0.617531121, -0.714061916, 0.343506157, -0.921160281, -0.182941139, -0.243016839, 0.100976005, -0.964752138, 0.907163978, 0.375856102, -0.189171538) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.38367605, -0.476294994, 1, 0, 0, 0, 0.984807789, 0.173647925, 0, -0.173647925, 0.984807789) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.65993702, -0.681548595, 1, 0, 0, 0, 0.984807789, -0.173647881, 0, 0.173647881, 0.984807789) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
	RootPart.Velocity = Vector3.new(0,6,0)
	prepareyourself.Pitch = prepareyourself.Pitch - .001
	WingWeld.C0 = clerp(WingWeld.C0, CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0 - 30 * math.cos(Sine/30)/2)), 0.1)
	Effects.Sphere2.Create(BrickColor.new(maincol), EffectModel, RightArm.CFrame * CFrame.new(.2,-1.1,0), 1.1, 1.1, 1.1, 1.1, 1.1, 1.1, .08)
	end	
	beet.Parent = Character
	local x = 1.1
	local y = 20
	CFuncs.Sound.Create("324849898", workspace, 10, .9)
		for i = 0, 20, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, 1.42191756, -0.0488209724, 1, 0, 0, 0, 0.965925872, 0.258818984, 0, -0.258818984, 0.965925872) * CFrame.new(0, 0 + .2 * math.cos(Sine/30), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.57220244, -0.165338278, 1, 0, 0, 0, 0.906307578, 0.422618866, 0, -0.422618866, 0.906307578) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(1.07328367, 0.536740482, -0.867595553, 0.405946076, 0.905454516, 0.123935826, 0.327782422, -0.0176637098, -0.944588244, -0.853092313, 0.424075872, -0.303962588) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.15903234, 0.617531121, -0.714061916, 0.343506157, -0.921160281, -0.182941139, -0.243016839, 0.100976005, -0.964752138, 0.907163978, 0.375856102, -0.189171538) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.38367605, -0.476294994, 1, 0, 0, 0, 0.984807789, 0.173647925, 0, -0.173647925, 0.984807789) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.65993702, -0.681548595, 1, 0, 0, 0, 0.984807789, -0.173647881, 0, 0.173647881, 0.984807789) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
		MagnitudeDamage(Torso, y, 0, 0, 0, "Normal", " ", 1)
		y = y + .3
		x = x + .1
	RootPart.Velocity = Vector3.new(0,2,0)
	WingWeld.C0 = clerp(WingWeld.C0, CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0 - 30 * math.cos(Sine/30)/2)), 0.1)
	Effects.Sphere2.Create(BrickColor.new(maincol), EffectModel, RightArm.CFrame * CFrame.new(.2,-1.1,0), x+.1, x+.1, x+.1, x+.1, x+.1, x+.1, .03)
		end	
	CFuncs.Sound.Create("665426491", workspace, 10, .9)
				for i = 0, 20, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, 1.42191756, -0.0488209724, 1, 0, 0, 0, 0.965925872, 0.258818984, 0, -0.258818984, 0.965925872) * CFrame.new(0, 0 + .2 * math.cos(Sine/30), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.57220244, -0.165338278, 1, 0, 0, 0, 0.906307578, 0.422618866, 0, -0.422618866, 0.906307578) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(1.07328367, 0.536740482, -0.867595553, 0.405946076, 0.905454516, 0.123935826, 0.327782422, -0.0176637098, -0.944588244, -0.853092313, 0.424075872, -0.303962588) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.15903234, 0.617531121, -0.714061916, 0.343506157, -0.921160281, -0.182941139, -0.243016839, 0.100976005, -0.964752138, 0.907163978, 0.375856102, -0.189171538) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.38367605, -0.476294994, 1, 0, 0, 0, 0.984807789, 0.173647925, 0, -0.173647925, 0.984807789) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.65993702, -0.681548595, 1, 0, 0, 0, 0.984807789, -0.173647881, 0, 0.173647881, 0.984807789) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
		MagnitudeDamage(Torso, y, 0, 0, 0, "Normal", " ", 1)
		y = y + .5
		x = x + .3
	RootPart.Velocity = Vector3.new(0,2,0)
	WingWeld.C0 = clerp(WingWeld.C0, CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0 - 30 * math.cos(Sine/30)/2)), 0.1)
	Effects.Sphere2.Create(BrickColor.new(maincol), EffectModel, RightArm.CFrame * CFrame.new(.2,-1.1,0), x+.1, x+.1, x+.1, x+.1, x+.1, x+.1, .03)
				end	
				CFuncs.Sound.Create("923073285", workspace, 10, .9)
								for i = 0, 20, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, 1.42191756, -0.0488209724, 1, 0, 0, 0, 0.965925872, 0.258818984, 0, -0.258818984, 0.965925872) * CFrame.new(0, 0 + .2 * math.cos(Sine/30), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.57220244, -0.165338278, 1, 0, 0, 0, 0.906307578, 0.422618866, 0, -0.422618866, 0.906307578) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(1.07328367, 0.536740482, -0.867595553, 0.405946076, 0.905454516, 0.123935826, 0.327782422, -0.0176637098, -0.944588244, -0.853092313, 0.424075872, -0.303962588) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.15903234, 0.617531121, -0.714061916, 0.343506157, -0.921160281, -0.182941139, -0.243016839, 0.100976005, -0.964752138, 0.907163978, 0.375856102, -0.189171538) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.38367605, -0.476294994, 1, 0, 0, 0, 0.984807789, 0.173647925, 0, -0.173647925, 0.984807789) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.65993702, -0.681548595, 1, 0, 0, 0, 0.984807789, -0.173647881, 0, 0.173647881, 0.984807789) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
		MagnitudeDamage(Torso, y, 0, 0, 0, "Normal", " ", 1)
		y = y + 2
		x = x + 1
	RootPart.Velocity = Vector3.new(0,2,0)
	WingWeld.C0 = clerp(WingWeld.C0, CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0 - 30 * math.cos(Sine/30)/2)), 0.1)
	Effects.Sphere2.Create(BrickColor.new(maincol), EffectModel, RightArm.CFrame * CFrame.new(.2,-1.1,0), x+.1, x+.1, x+.1, x+.1, x+.1, x+.1, .03)
								end	
															 for y,t in pairs(Character:GetChildren()) do
                                                                  if t:IsA("Part") then
                                                                  table.insert(Effects, {t,"Disappear",.008})
									t.Material = "Neon"
									t.Parent = workspace
                                    t:BreakJoints()
									t.BrickColor = BrickColor.new(maincol)
									t.CanCollide = true
									local GRAVITY_ACCELERATION = 200
									local bodyForce = Instance.new('BodyForce', t)
									bodyForce.Name = 'Antigravity'
									bodyForce.force = Vector3.new(0, t:GetMass() * GRAVITY_ACCELERATION, 0)
									t.Velocity=Vector3.new(math.random(-1, 1),math.random(-1, 1),math.random(-1, 1))
									local rl = Create("BodyAngularVelocity"){
									P = 500,
									maxTorque = Vector3.new(5, 5, 5),
									angularvelocity = Vector3.new(math.random(-10, 10), math.random(-10, 10), math.random(-10, 10)),
									Parent = t,}
									game:GetService("Debris"):AddItem(t, 3)
									for a,b in pairs(t:GetChildren()) do
                                    if b:IsA("Decal") then
									b:Destroy()

end
end
end
end
end

function warp2self()
	Attack = true
	local hit = Mouse.Target.Parent
		if hit:FindFirstChildOfClass("Humanoid") ~= nil and hit ~= Character then
			Effects.Sphere2.Create(BrickColor.new(maincol), EffectModel, hit.Torso.CFrame, 2, 2, 2, 2, 2, 2, .03)
			CFuncs.Sound.Create("403075587", hit.Torso, 1, 1)
		end
		for i = 0, 1, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, 1.50806487, -0.0493182242, 1, 0, 0, 0, 0.965925872, 0.258818984, 0, -0.258818984, 0.965925872) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.57220507, -0.165325716, 1, 0, 0, 0, 0.99619478, -0.0871558785, 0, 0.0871558785, 0.99619478) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.770143628, 1.15917659, -0.772669554, 0.669632196, 0.727706075, -0.148447335, 0.385774463, -0.511604011, -0.767749667, -0.634642303, 0.456842661, -0.623317003) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.15002179, 0.770601869, -1.3447417, 0.150704995, -0.239807919, 0.959051669, 0.988570929, 0.0404406041, -0.145231575, -0.00395695865, 0.969977796, 0.243161768) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.38367522, -0.476285875, 1, 0, 0, 0, 0.99619478, -0.0871558785, 0, 0.0871558785, 0.99619478) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.97375286, -0.38368547, 1, 0, 0, 0, 0.99619478, -0.0871558785, 0, 0.0871558785, 0.99619478) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
		end
		if hit:FindFirstChildOfClass("Humanoid") ~= nil and hit ~= Character then
			hit.Torso.CFrame = RootPart.CFrame * CFrame.new(0,0,-3)
			Effects.Sphere2.Create(BrickColor.new(maincol), EffectModel, hit.Torso.CFrame, 2, 2, 2, 2, 2, 2, .03)
			CFuncs.Sound.Create("1770550108", hit.Torso, 1, 1)
		end
		for i = 0, 3, 0.1 do
		swait()
		PlayAnimationFromTable({
         CFrame.new(0, 1.25783896, 0.0750579834, 1, 0, 0, 0, 1, 0, 0, 0, 1) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.5722059, -0.165335715, 1, 0, 0, 0, 0.996194661, 0.087155968, 0, -0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.770152092, 1.15917587, -0.772684395, 0.669632077, 0.727706194, -0.14844726, 0.385775059, -0.511604249, -0.767749131, -0.634642065, 0.456842214, -0.62331754) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.29209483, 1.91917002, -0.0983848572, -0.225760028, -0.171030968, 0.959052086, 0.12644501, -0.981284738, -0.145230755, 0.965942144, 0.0884800404, 0.243160874) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.38367569, -0.476289868, 1, 0, -0, 0, 0.996194661, -0.087155968, 0, 0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.97375119, -0.383697003, 1, 0, -0, 0, 0.996194661, -0.087155968, 0, 0.087155968, 0.996194661) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
	end
	Attack = false
end


Mouse.Button1Down:connect(function()
	if Attack == false and Combo == 1 then
       punch1()
		Combo = 1
	end
end)	
	

Mouse.KeyDown:connect(function(Key)
	Key = Key:lower()
		if Attack == false and Key == 'z' and dash == false then
		dash = true
		elseif Attack == false and Key == 'z' and dash == true then
		dash = false
		elseif Attack == false and Key == 'c' and dash  == false then
		explodeatmouse()
		elseif Attack == false and Key == 'v' and dash  == false and deathrain == false then
		armagedd()
		elseif Attack == false and Key == 'x' and dash  == false then
		bring()
		elseif Attack == false and Key == 'b' and dash  == false then
		obliterate()
		elseif Attack == false and Key == 'n' and dash  == false then
		warp2self()
		elseif Attack == false and Key == 'm' and dash  == false then
		detonate()
end
end)

coroutine.wrap(function()
while true do
	swait()
	for i, v in pairs(Character:GetChildren()) do
		if v:IsA("Part") then
			v.Material = "SmoothPlastic"
		elseif v:IsA("Accessory") then
			v:WaitForChild("Handle").Material = "SmoothPlastic"
		end
	end
	for i, v in pairs(Character:GetChildren()) do
		if v:IsA'Model' then
			for _, c in pairs(v:GetChildren()) do
				if c:IsA'Part' then
					c.CustomPhysicalProperties = PhysicalProperties.new(0.001, 0.001, 0.001, 0.001, 0.001)
				end
			end
		end
	end
	TorsoVelocity = (RootPart.Velocity * Vector3.new(1, 0, 1)).magnitude 
	Velocity = RootPart.Velocity.y
	Sine = Sine + Change
	local hit, pos = RayCast(RootPart.Position, (CFrame.new(RootPart.Position, RootPart.Position - Vector3.new(0, 1, 0))).lookVector, 4, Character)
	if RootPart.Velocity.y > 1 and hit == nil then 
		Anim = "Jump"
		if Attack == false then
			Change = 1
		PlayAnimationFromTable({
         CFrame.new(-0.0142319221, 0.0233184248, 0.0206878185, 1.00000012, 1.49011612e-08, 0, 2.72463048e-08, 0.965925992, 0.258818656, 2.98023224e-08, -0.258818597, 0.965925932) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.0172861218, 1.54588914, -0.00366462767, 0.999084175, 0.00742999092, -0.0421376228, -0.011074245, 0.996153653, -0.0869220346, 0.0413297117, 0.0873090774, 0.995323658) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(1.54051697, 0.254249156, -0.521965742, 0.890014946, -0.152965426, -0.429505706, -0.32768172, 0.440404594, -0.835864007, 0.317014515, 0.884672523, 0.341842651) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.55745959, 0.112057857, 0.343250573, 0.986049891, 0.113037676, 0.12218184, -0.158506706, 0.861737013, 0.481959641, -0.050808996, -0.49460274, 0.867632747) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.566533923, -1.59700418, -0.481964171, 0.999206185, -0.0385679156, -0.00998616219, 0.0397087261, 0.94381088, 0.328091979, -0.00322881341, -0.328228056, 0.944592893) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.433014154, -1.95977831, 0.0051856637, 1, 0, 0, 0, 0.965925813, 0.258819401, -2.98023224e-08, -0.258819431, 0.965925753) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .1, false)
		Trace()
		end
	elseif RootPart.Velocity.y < -1 and hit == nil then 
		Anim = "Fall"
		if Attack == false then
			Change = 1
		PlayAnimationFromTable({
         CFrame.new(-0.0142319212, 0.0233183783, 0.0206877608, 1.00000012, 1.49011612e-08, 2.98023224e-08, 2.72463048e-08, 0.984807968, 0.173647314, 2.98023224e-08, -0.17364724, 0.984807849) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.0154076805, 1.5522356, -0.0916171968, 0.999084175, 0.0180828422, -0.0387787819, -0.00742995739, 0.9658584, 0.258964151, 0.0421376526, -0.258438855, 0.965108156) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(1.44003379, 0.0510732532, -0.418421805, 0.890014946, -0.0760585517, -0.449542671, -0.298804998, 0.647417247, -0.701118112, 0.344367683, 0.75833106, 0.553484201) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.55745959, 0.141547889, 0.332177758, 0.986049891, 0.113037676, 0.12218184, -0.162331849, 0.815350056, 0.555745184, -0.036800772, -0.567826271, 0.822325349) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.573113441, -1.8059541, -0.374102622, 0.999206126, -0.0373207629, 0.0139417946, 0.0392762311, 0.98143959, -0.187706873, -0.00667765737, 0.188105404, 0.982126117) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.433013678, -1.95186841, 0.175973177, 1, 0, 2.98023224e-08, 0, 0.98480773, 0.173648328, 2.98023224e-08, -0.173648328, 0.984807789) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .05, false)
		Trace()
		end		
	elseif TorsoVelocity < 1 and hit ~= nil then
		Anim = "Idle"
		if Attack == false then
			Change = 1
		PlayAnimationFromTable({
         CFrame.new(0, 1.37272656, 1.63912773e-06, 1, 0, 0, 0, 0.984807849, 0.173647985, 0, -0.173647985, 0.984807849) * CFrame.new(0, 0 + .2 * math.cos(Sine/30), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.57220602, -0.165335596, 1, 0, 0, 0, 0.99619478, 0.0871558785, 0, -0.0871558785, 0.99619478) * CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(math.random(-20,20)), 0, math.rad(math.random(-20,20))), 
         CFrame.new(0.923389256, 1.14993238, -0.616622925, 0.835160017, 0.529595375, -0.148447037, 0.240216389, -0.594018042, -0.76774925, -0.494776666, 0.605533957, -0.623317599) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, math.rad(math.random(-20,20))), 
         CFrame.new(-1.59592402, 0.175992578, 0.0587863736, 0, 0.173650011, 0.984807491, 0.0871323273, 0.981062055, -0.172989562, -0.996196866, 0.0858085677, -0.0151305255) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.38367629, -0.476296663, 1, 0, 0, 0, 0.99619478, -0.0871553123, 0, 0.0871553123, 0.99619478) * CFrame.new(0, 0 + .1 * math.cos(Sine/30), 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -1.97375131, -0.383703351, 1, 0, 0, 0, 0.99619478, -0.0871553123, 0, 0.0871553123, 0.99619478) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .05, false)
		WingWeld.C0 = clerp(WingWeld.C0, CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(0 - 30 * math.cos(Sine/30)/2)), 0.1)
		end
	elseif TorsoVelocity > 2 and hit ~= nil then
		Anim = "Walk"
            if Attack == false then
		PlayAnimationFromTable({
         CFrame.new(0, 1.4926281, -0.36127466, 1, 0, 0, 0, 0.64278698, 0.766044974, 0, -0.766044974, 0.64278698) * CFrame.new(0, 0, 0 + .2 * math.cos(Sine/20)) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0, 1.56528306, -0.0329420865, 1, 0, 0, 0, 0.939692497, -0.34202078, 0, 0.34202078, 0.939692497) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.811238647, 1.3424753, -0.671978116, 0.795616865, 0.488440514, -0.358357012, 0.314500928, -0.838608742, -0.444774866, -0.51776731, 0.2411668, -0.820826232) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-1.63549292, -0.0676899552, 0.268951952, -0.0868249685, 0.150387108, 0.984807193, -0.415071368, 0.89319092, -0.172991171, -0.905636311, -0.423785239, -0.0151298866) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(0.5, -1.49318743, -0.532121181, 1, 0, 0, 0, 0.99619472, 0.0871558785, 0, -0.0871558785, 0.99619472) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
         CFrame.new(-0.5, -2.11923432, 0.210574031, 1, 0, 0, 0, 0.866025209, 0.500000298, 0, -0.500000298, 0.866025209) * CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0), 
		}, .05, false)
		Trace()
		WingWeld.C0 = clerp(WingWeld.C0, CFrame.new(0, 0, 0) * CFrame.Angles(math.rad(0), math.rad(0), math.rad(-20 + 40 * math.cos(Sine/20)/2)), 0.1)
		end
	end
	if #Effects > 0 then
		for e = 1, #Effects do
			if Effects[e] ~= nil then
				local Thing = Effects[e]
				if Thing ~= nil then
					local Part = Thing[1]
					local Mode = Thing[2]
					local Delay = Thing[3]
					local IncX = Thing[4]
					local IncY = Thing[5]
					if Thing[1].Transparency <= 1 then
						if Thing[2] == "Block1" then
							Thing[1].CFrame = Thing[1].CFrame * CFrame.fromEulerAnglesXYZ(math.random(-50, 50), math.random(-50, 50), math.random(-50, 50))
							Mesh = Thing[7]
							Mesh.Scale = Mesh.Scale + Vector3.new(Thing[4], Thing[5], Thing[6])
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
						elseif Thing[2] == "Ice" then
							if Thing[6] <= Thing[5] then
								Thing[6] = Thing[6] + .05
								Thing[1].CFrame = Thing[1].CFrame * CFrame.new(0, .4, 0)
							else
								Thing[1].Transparency = Thing[1].Transparency + Thing[3]
							end
						elseif Thing[2] == "Shatter" then
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
							Thing[4] = Thing[4] * CFrame.new(0, Thing[7], 0)
							Thing[1].CFrame = Thing[4] * CFrame.fromEulerAnglesXYZ(Thing[6], 0, 0)
							Thing[6] = Thing[6] + Thing[5]
						elseif Thing[2] == "Block2" then
							Thing[1].CFrame = Thing[1].CFrame
							Mesh = Thing[7]
							Mesh.Scale = Mesh.Scale + Vector3.new(Thing[4], Thing[5], Thing[6])
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
						elseif Thing[2] == "Block3" then
							Thing[1].CFrame = Thing[8].CFrame * CFrame.fromEulerAnglesXYZ(math.random(-50, 50), math.random(-50, 50), math.random(-50, 50))
							Mesh = Thing[7]
							Mesh.Scale = Mesh.Scale + Vector3.new(Thing[4], Thing[5], Thing[6])
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
						elseif Thing[2] == "Block4" then
							Thing[1].CFrame = Thing[8].CFrame * CFrame.new(0, -Thing[7].Scale.Y, 0) * CFrame.fromEulerAnglesXYZ(3.14, 0, 0)
							Mesh = Thing[7]
							Mesh.Scale = Mesh.Scale + Vector3.new(Thing[4], Thing[5], Thing[6])
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
						elseif Thing[2] == "Block2Fire" then
							Thing[1].CFrame = Thing[1].CFrame * CFrame.fromEulerAnglesXYZ(math.random(-50, 50), math.random(-50, 50), math.random(-50, 50))
							Mesh = Thing[7]
							Mesh.Scale = Mesh.Scale + Vector3.new(Thing[4], Thing[5], Thing[6])
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
							if Thing[1].Transparency >= .3 then
								Thing[1].BrickColor = BrickColor.new("Bright red")
							else
								Thing[1].BrickColor = BrickColor.new("Bright yellow")
							end
						elseif Thing[2] == "Cylinder" then
							Mesh = Thing[7]
							Mesh.Scale = Mesh.Scale + Vector3.new(Thing[4], Thing[5], Thing[6])
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
						elseif Thing[2] == "Blood" then
							Mesh = Thing[7]
							Thing[1].CFrame = Thing[1].CFrame * CFrame.new(0, -.5, 0)
							Mesh.Scale = Mesh.Scale + Vector3.new(Thing[4], Thing[5], Thing[6])
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
						elseif Thing[2] == "Elec" then
							Mesh = Thing[10]
							Mesh.Scale = Mesh.Scale + Vector3.new(Thing[7], Thing[8], Thing[9])
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
							Thing[1].CFrame = Thing[1].CFrame * Thing[11] * CFrame.new(0, 0, .2)
							Thing[1].Rotation = Vector3.new(0, 0, 0)
						elseif Thing[2] == "Disappear" then
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
						end
					else
						Part.Parent = nil
						table.remove(Effects, e)
					end
				end
			end
		end
	end
	if dash == true then
	RootPart.Velocity = RootPart.CFrame.lookVector * 100
	end
end
end)()
